# Fossa Racing 3D — Android Production Build & AdMob Guide

## 1. Build-Type AdMob Separation (Debug vs Release)
`app/build.gradle.kts` automatically isolates development and production AdMob IDs via `manifestPlaceholders["admobAppId"]` and `BuildConfig`:

| Setting | `debug` (Development Build) | `release` (Production Build) |
|---|---|---|
| **AdMob App ID** | `ca-app-pub-3940256099942544~3347511713` | `ca-app-pub-7511229662294549~7706649838` |
| **Banner Unit** | `ca-app-pub-3940256099942544/6300978111` | `ca-app-pub-7511229662294549/3791455558` |
| **Interstitial Unit** | `ca-app-pub-3940256099942544/1033173712` | `ca-app-pub-7511229662294549/8574163894` |
| **Rewarded Unit** | `ca-app-pub-3940256099942544/5224354917` | `ca-app-pub-7511229662294549/4443347191` |

- `AndroidManifest.xml` binds `com.google.android.gms.ads.APPLICATION_ID` to `${admobAppId}` so debug builds always test safely with Google test ads and release builds automatically package your production App ID.

---

## 2. Ad Placements & Safety Guards
- **Banner Ads**: Shown on the **Home Screen (`MENU`)** only and collapsed during racing or if loading fails (`AdListener`).
- **Interstitial Ads**: Preloaded during races and shown **after completed races** only—strictly blocked during active gameplay (`isGameplayActive`) and capped at **every 2nd race + 90s minimum cooldown**.
- **Rewarded Ads (+500 Coins)**: Available on the **Home Screen** and **Post-Race Results** (`+500 COINS (AD)`). Coins (`+500`) are granted **only** after `OnUserEarnedRewardListener` fires and `shown === true && rewarded === true && rewardAmount === 500` is verified.

---

## 3. Android Build Commands

1. **Verify Integration & Unit Tests**:
   ```bash
   gradle :app:testDebugUnitTest
   ```

2. **Build Development APK (uses Google Test Ad IDs)**:
   ```bash
   gradle assembleDebug
   ```
   Output: `app/build/outputs/apk/debug/app-debug.apk`

3. **Build Signed Production Release APK / Play Store AAB (uses Production AdMob IDs)**:
   Set your signing environment variables (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`) and run:
   ```bash
   gradle assembleRelease
   # or for Google Play Store (.aab):
   gradle bundleRelease
   ```
   Outputs:
   - `app/build/outputs/apk/release/app-release.apk`
   - `app/build/outputs/bundle/release/app-release.aab`
