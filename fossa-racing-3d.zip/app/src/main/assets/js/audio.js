(function (global) {
  'use strict';

  class FossaAudio {
    constructor() {
      this.ctx = null;
      this.enabled = true;
      this.engineOsc1 = null;
      this.engineOsc2 = null;
      this.engineGain = null;
      this.engineFilter = null;
      this.nitroGain = null;
      this.engineRunning = false;
    }

    setEnabled(val) {
      this.enabled = !!val;
      if (!this.enabled) {
        this.stopEngine();
      }
    }

    ensureContext() {
      if (!this.enabled) return null;
      if (!this.ctx) {
        const AudioCtx = global.AudioContext || global.webkitAudioContext;
        if (!AudioCtx) return null;
        this.ctx = new AudioCtx();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    }

    startEngine() {
      const ctx = this.ensureContext();
      if (!ctx || this.engineRunning) return;

      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'triangle';
      osc1.frequency.value = 55;
      osc2.frequency.value = 110;

      filter.type = 'lowpass';
      filter.frequency.value = 380;
      filter.Q.value = 2.2;

      gain.gain.value = 0.0;

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc1.start();
      osc2.start();

      this.engineOsc1 = osc1;
      this.engineOsc2 = osc2;
      this.engineFilter = filter;
      this.engineGain = gain;
      this.engineRunning = true;
    }

    updateEngine(speedRatio, isNitro, isPaused) {
      if (!this.enabled || !this.engineRunning || !this.ctx) return;
      const now = this.ctx.currentTime;
      if (isPaused) {
        this.engineGain.gain.setTargetAtTime(0.0, now, 0.05);
        return;
      }

      // Simulate 6-speed gear cadence
      const gears = 6;
      const scaled = Math.max(0, Math.min(1, speedRatio)) * gears;
      const gearFrac = scaled % 1;
      const baseHz = 48 + speedRatio * 78 + gearFrac * 42 + (isNitro ? 36 : 0);

      this.engineOsc1.frequency.setTargetAtTime(baseHz, now, 0.06);
      this.engineOsc2.frequency.setTargetAtTime(baseHz * 1.98, now, 0.06);
      this.engineFilter.frequency.setTargetAtTime(280 + speedRatio * 950 + (isNitro ? 600 : 0), now, 0.07);
      const targetVol = 0.045 + speedRatio * 0.05 + (isNitro ? 0.03 : 0);
      this.engineGain.gain.setTargetAtTime(targetVol, now, 0.08);
    }

    stopEngine() {
      if (!this.engineRunning) return;
      try {
        this.engineOsc1.stop();
        this.engineOsc2.stop();
        this.engineOsc1.disconnect();
        this.engineOsc2.disconnect();
        this.engineGain.disconnect();
      } catch (_) {}
      this.engineOsc1 = null;
      this.engineOsc2 = null;
      this.engineGain = null;
      this.engineFilter = null;
      this.engineRunning = false;
    }

    playCoin() {
      const ctx = this.ensureContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(980, now);
      osc.frequency.exponentialRampToValueAtTime(1480, now + 0.09);
      gain.gain.setValueAtTime(0.11, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.17);
    }

    playNearMiss() {
      const ctx = this.ensureContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(190, now + 0.18);
      gain.gain.setValueAtTime(0.09, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    }

    playCollision() {
      const ctx = this.ensureContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(34, now + 0.28);
      gain.gain.setValueAtTime(0.22, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.30);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.31);
    }

    playCountdown(isGo) {
      const ctx = this.ensureContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(isGo ? 880 : 440, now);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + (isGo ? 0.32 : 0.14));
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + (isGo ? 0.33 : 0.15));
    }

    playClick() {
      const ctx = this.ensureContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(620, now);
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.07);
    }
  }

  global.FossaAudio = new FossaAudio();
})(window);
