(function (global) {
  'use strict';

  const cachedTextures = {};

  function getRoadTexture() {
    if (cachedTextures.road) return cachedTextures.road;
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    // Asphalt base
    ctx.fillStyle = '#1b1d24';
    ctx.fillRect(0, 0, 512, 512);

    // Subtle aggregate grain
    for (let i = 0; i < 3200; i++) {
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      const v = 22 + Math.floor(Math.random() * 24);
      ctx.fillStyle = `rgb(${v},${v + 2},${v + 6})`;
      ctx.fillRect(x, y, 2, 2);
    }

    // Racing red & white shoulder kerbs on outer edges
    const kerbW = 24;
    const segs = 8;
    const segH = 512 / segs;
    for (let i = 0; i < segs; i++) {
      ctx.fillStyle = i % 2 === 0 ? '#e10600' : '#f2f4f8';
      ctx.fillRect(0, i * segH, kerbW, segH);
      ctx.fillRect(512 - kerbW, i * segH, kerbW, segH);
    }

    // Solid outer white lane lines
    ctx.fillStyle = '#e8ecf2';
    ctx.fillRect(kerbW + 4, 0, 7, 512);
    ctx.fillRect(512 - kerbW - 11, 0, 7, 512);

    // 4 lanes => 3 inner dashed dividers
    const roadInnerStart = kerbW + 11;
    const roadInnerWidth = 512 - (kerbW + 11) * 2;
    const laneW = roadInnerWidth / 4;

    for (let l = 1; l <= 3; l++) {
      const x = roadInnerStart + laneW * l - 3;
      ctx.fillStyle = l === 2 ? 'rgba(255, 220, 90, 0.88)' : 'rgba(235, 240, 248, 0.78)';
      for (let y = 16; y < 512; y += 64) {
        ctx.fillRect(x, y, 6, 36);
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(1, 2);
    tex.anisotropy = 4;
    cachedTextures.road = tex;
    return tex;
  }

  function getBuildingTexture(variant) {
    const key = 'bldg_' + variant;
    if (cachedTextures[key]) return cachedTextures[key];

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    const palettes = [
      { wall: '#141720', winOn: '#ffe5a3', winDim: '#242b3b', stripe: '#e10600' },
      { wall: '#181a22', winOn: '#9be2ff', winDim: '#222836', stripe: '#ffffff' },
      { wall: '#111319', winOn: '#ffd089', winDim: '#1e222e', stripe: '#e10600' },
    ];
    const pal = palettes[variant % palettes.length];

    ctx.fillStyle = pal.wall;
    ctx.fillRect(0, 0, 256, 512);

    const cols = 6;
    const rows = 16;
    const padX = 12;
    const padY = 12;
    const cellW = (256 - padX * 2) / cols;
    const cellH = (512 - padY * 2) / rows;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const lit = Math.random() > 0.36;
        ctx.fillStyle = lit ? pal.winOn : pal.winDim;
        ctx.fillRect(
          padX + c * cellW + 4,
          padY + r * cellH + 5,
          cellW - 8,
          cellH - 10
        );
      }
    }

    // Rooftop neon accent band
    ctx.fillStyle = pal.stripe;
    ctx.fillRect(0, 8, 256, 10);

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    cachedTextures[key] = tex;
    return tex;
  }

  function createWheel(radius, width, rimColorHex) {
    const wheelGroup = new THREE.Group();

    const tireGeo = new THREE.CylinderGeometry(radius, radius, width, 18);
    tireGeo.rotateZ(Math.PI / 2);
    const tireMat = new THREE.MeshStandardMaterial({
      color: 0x16181e,
      roughness: 0.85,
      metalness: 0.1,
    });
    const tire = new THREE.Mesh(tireGeo, tireMat);
    tire.castShadow = true;
    wheelGroup.add(tire);

    const rimGeo = new THREE.CylinderGeometry(radius * 0.64, radius * 0.64, width + 0.02, 12);
    rimGeo.rotateZ(Math.PI / 2);
    const rimMat = new THREE.MeshStandardMaterial({
      color: rimColorHex || 0xd6dbe6,
      roughness: 0.25,
      metalness: 0.85,
    });
    const rim = new THREE.Mesh(rimGeo, rimMat);
    wheelGroup.add(rim);

    // 5-spoke visual cross bars so wheel spin is clearly visible
    const spokeGeo = new THREE.BoxGeometry(width + 0.04, radius * 1.15, 0.08);
    const spokeMat = new THREE.MeshStandardMaterial({
      color: 0x262933,
      roughness: 0.35,
      metalness: 0.7,
    });
    for (let i = 0; i < 3; i++) {
      const spoke = new THREE.Mesh(spokeGeo, spokeMat);
      spoke.rotation.x = (i * Math.PI) / 3;
      wheelGroup.add(spoke);
    }

    // Red brake caliper inside wheel
    const caliperGeo = new THREE.BoxGeometry(width * 0.5, 0.18, 0.22);
    const caliperMat = new THREE.MeshBasicMaterial({ color: 0xe10600 });
    const caliper = new THREE.Mesh(caliperGeo, caliperMat);
    caliper.position.set(0, 0.08, -radius * 0.38);
    wheelGroup.add(caliper);

    return wheelGroup;
  }

  function createPlayerCar(carSpec, paintHex) {
    const root = new THREE.Group();
    const chassis = new THREE.Group();
    root.add(chassis);

    const sx = carSpec.bodyScale ? carSpec.bodyScale[0] : 1;
    const sy = carSpec.bodyScale ? carSpec.bodyScale[1] : 1;
    const sz = carSpec.bodyScale ? carSpec.bodyScale[2] : 1;

    const bodyPaintMat = new THREE.MeshStandardMaterial({
      color: paintHex != null ? paintHex : carSpec.defaultColor,
      roughness: 0.22,
      metalness: 0.62,
    });

    const carbonMat = new THREE.MeshStandardMaterial({
      color: 0x15171d,
      roughness: 0.55,
      metalness: 0.35,
    });

    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x0b1220,
      roughness: 0.08,
      metalness: 0.9,
      transparent: true,
      opacity: 0.9,
    });

    const chromeMat = new THREE.MeshStandardMaterial({
      color: 0xe2e6ee,
      roughness: 0.18,
      metalness: 0.92,
    });

    // Lower Carbon Chassis Floor & Front Splitter
    const floorMesh = new THREE.Mesh(new THREE.BoxGeometry(2.14 * sx, 0.18, 4.65 * sz), carbonMat);
    floorMesh.position.set(0, 0.34, 0);
    floorMesh.castShadow = true;
    chassis.add(floorMesh);

    const splitter = new THREE.Mesh(new THREE.BoxGeometry(2.18 * sx, 0.08, 0.55), carbonMat);
    splitter.position.set(0, 0.26, -2.26 * sz);
    chassis.add(splitter);

    // Sculpted Main Body Core
    const lowerBody = new THREE.Mesh(new THREE.BoxGeometry(2.04 * sx, 0.44 * sy, 4.44 * sz), bodyPaintMat);
    lowerBody.position.set(0, 0.60, 0);
    lowerBody.castShadow = true;
    lowerBody.receiveShadow = true;
    chassis.add(lowerBody);

    // Front Sloped Hood
    const hood = new THREE.Mesh(new THREE.BoxGeometry(1.86 * sx, 0.22 * sy, 1.55 * sz), bodyPaintMat);
    hood.position.set(0, 0.78, -1.25 * sz);
    hood.rotation.x = 0.11;
    hood.castShadow = true;
    chassis.add(hood);

    // Hood Intake Scoop
    const scoop = new THREE.Mesh(new THREE.BoxGeometry(0.62 * sx, 0.09, 0.58), carbonMat);
    scoop.position.set(0, 0.89, -1.05 * sz);
    chassis.add(scoop);

    // Side Flared Fenders (Front & Rear)
    const fenderGeo = new THREE.BoxGeometry(0.22, 0.34, 0.96);
    [
      [-0.99 * sx, 0.64, -1.32 * sz],
      [0.99 * sx, 0.64, -1.32 * sz],
      [-1.01 * sx, 0.66, 1.32 * sz],
      [1.01 * sx, 0.66, 1.32 * sz],
    ].forEach((p) => {
      const f = new THREE.Mesh(fenderGeo, bodyPaintMat);
      f.position.set(p[0], p[1], p[2]);
      f.castShadow = true;
      chassis.add(f);
    });

    // Cabin Greenhouse & Tinted Glass
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.56 * sx, 0.48 * sy, 2.05 * sz), glassMat);
    cabin.position.set(0, 1.01, 0.12 * sz);
    cabin.castShadow = true;
    chassis.add(cabin);

    // Painted Roof Panel
    const roof = new THREE.Mesh(new THREE.BoxGeometry(1.48 * sx, 0.08, 1.25 * sz), bodyPaintMat);
    roof.position.set(0, 1.25 * sy + 0.02, 0.2 * sz);
    roof.castShadow = true;
    chassis.add(roof);

    // Racing Stripes down center
    const stripeMat = new THREE.MeshStandardMaterial({
      color: paintHex === 0xf4f5f7 ? 0xe10600 : 0xffffff,
      roughness: 0.25,
      metalness: 0.4,
    });
    const hoodStripe = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.02, 1.48 * sz), stripeMat);
    hoodStripe.position.set(0, 0.90, -1.26 * sz);
    hoodStripe.rotation.x = 0.11;
    chassis.add(hoodStripe);

    const roofStripe = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.02, 1.22 * sz), stripeMat);
    roofStripe.position.set(0, 1.29 * sy + 0.02, 0.2 * sz);
    chassis.add(roofStripe);

    // Side Mirrors
    [-0.95 * sx, 0.95 * sx].forEach((mx) => {
      const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.11, 0.16), bodyPaintMat);
      mirror.position.set(mx, 0.92, -0.45 * sz);
      chassis.add(mirror);
    });

    // Rear Deck & Diffuser
    const rearDeck = new THREE.Mesh(new THREE.BoxGeometry(1.90 * sx, 0.24, 0.95 * sz), bodyPaintMat);
    rearDeck.position.set(0, 0.86, 1.55 * sz);
    rearDeck.castShadow = true;
    chassis.add(rearDeck);

    const diffuser = new THREE.Mesh(new THREE.BoxGeometry(1.88 * sx, 0.22, 0.34), carbonMat);
    diffuser.position.set(0, 0.35, 2.18 * sz);
    chassis.add(diffuser);

    // Model-Specific Spoiler Wing
    const wingY = carSpec.wingType === 'gt_tall' || carSpec.wingType === 'f1' ? 1.32 : 1.16;
    if (carSpec.wingType === 'ducktail') {
      const duck = new THREE.Mesh(new THREE.BoxGeometry(1.94 * sx, 0.16, 0.28), bodyPaintMat);
      duck.position.set(0, 1.03, 2.02 * sz);
      duck.rotation.x = -0.35;
      chassis.add(duck);
    } else {
      const wingBlade = new THREE.Mesh(new THREE.BoxGeometry(2.12 * sx, 0.07, 0.34), carbonMat);
      wingBlade.position.set(0, wingY, 2.02 * sz);
      wingBlade.rotation.x = 0.12;
      wingBlade.castShadow = true;
      chassis.add(wingBlade);

      [-0.68 * sx, 0.68 * sx].forEach((sxPos) => {
        const strut = new THREE.Mesh(new THREE.BoxGeometry(0.06, wingY - 0.92, 0.16), carbonMat);
        strut.position.set(sxPos, 0.92 + (wingY - 0.92) / 2, 1.98 * sz);
        chassis.add(strut);

        const endplate = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.22, 0.42), bodyPaintMat);
        endplate.position.set(sxPos > 0 ? 1.06 * sx : -1.06 * sx, wingY, 2.02 * sz);
        chassis.add(endplate);
      });

      if (carSpec.wingType === 'f1') {
        const sharkFin = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.34, 0.92), bodyPaintMat);
        sharkFin.position.set(0, 1.34, 1.25 * sz);
        chassis.add(sharkFin);
      }
    }

    // Twin LED Headlights + Subtle Ground Beam Glow
    const headMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    [-0.68 * sx, 0.68 * sx].forEach((hx) => {
      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.11, 0.08), headMat);
      hl.position.set(hx, 0.63, -2.23 * sz);
      chassis.add(hl);
    });

    // Headlight ground projection cones
    const beamGeo = new THREE.ConeGeometry(1.1, 7.5, 16, 1, true);
    beamGeo.rotateX(Math.PI / 2);
    const beamMat = new THREE.MeshBasicMaterial({
      color: 0xdbeeff,
      transparent: true,
      opacity: 0.10,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    [-0.65 * sx, 0.65 * sx].forEach((bx) => {
      const beam = new THREE.Mesh(beamGeo, beamMat);
      beam.position.set(bx, 0.22, -6.0 * sz);
      beam.scale.set(1, 0.18, 1);
      chassis.add(beam);
    });

    // Dynamic Crimson Taillights (intensify when braking)
    const brakeMat = new THREE.MeshBasicMaterial({ color: 0xff1e1e });
    const tailBar = new THREE.Mesh(new THREE.BoxGeometry(1.78 * sx, 0.11, 0.08), brakeMat);
    tailBar.position.set(0, 0.72, 2.23 * sz);
    chassis.add(tailBar);

    // Exhaust Pipes & Nitro Flame Cones
    const nitroFlames = [];
    const flameGeo = new THREE.ConeGeometry(0.11, 1.15, 10);
    flameGeo.rotateX(-Math.PI / 2);
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0x00e5ff,
      transparent: true,
      opacity: 0.9,
    });
    const innerFlameMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.95,
    });

    const exPositions =
      carSpec.exhausts === 4 ? [-0.62, -0.42, 0.42, 0.62] : [-0.48, 0.48];
    exPositions.forEach((ex) => {
      const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.24, 10), chromeMat);
      pipe.rotation.x = Math.PI / 2;
      pipe.position.set(ex * sx, 0.35, 2.26 * sz);
      chassis.add(pipe);

      const flameGroup = new THREE.Group();
      flameGroup.position.set(ex * sx, 0.35, 2.86 * sz);
      const outer = new THREE.Mesh(flameGeo, flameMat);
      const inner = new THREE.Mesh(flameGeo, innerFlameMat);
      inner.scale.set(0.55, 0.55, 0.72);
      flameGroup.add(outer);
      flameGroup.add(inner);
      flameGroup.visible = false;
      chassis.add(flameGroup);
      nitroFlames.push(flameGroup);
    });

    // 4 Spinning Wheels (Front 2 on steering pivots)
    const wheels = [];
    const frontSteerPivots = [];
    const wheelY = 0.37;
    const wheelOffsets = [
      { x: -0.98 * sx, z: -1.32 * sz, front: true },
      { x: 0.98 * sx, z: -1.32 * sz, front: true },
      { x: -1.00 * sx, z: 1.32 * sz, front: false },
      { x: 1.00 * sx, z: 1.32 * sz, front: false },
    ];

    wheelOffsets.forEach((w) => {
      const wMesh = createWheel(0.38, 0.28, 0xd8dce6);
      if (w.front) {
        const pivot = new THREE.Group();
        pivot.position.set(w.x, wheelY, w.z);
        pivot.add(wMesh);
        root.add(pivot);
        frontSteerPivots.push(pivot);
      } else {
        wMesh.position.set(w.x, wheelY, w.z);
        root.add(wMesh);
      }
      wheels.push(wMesh);
    });

    return {
      group: root,
      chassis,
      wheels,
      frontSteerPivots,
      brakeMat,
      nitroFlames,
      bodyPaintMat,
    };
  }

  function createTrafficCar(type, colorHex) {
    const group = new THREE.Group();
    const paintMat = new THREE.MeshStandardMaterial({
      color: colorHex,
      roughness: 0.38,
      metalness: 0.45,
    });
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x101722,
      roughness: 0.15,
      metalness: 0.85,
    });
    const darkMat = new THREE.MeshStandardMaterial({
      color: 0x191b22,
      roughness: 0.75,
    });

    let width = 1.95;
    let length = 4.3;
    let bodyH = 0.62;
    let cabinH = 0.54;
    let cabinL = 2.0;

    if (type === 'suv') {
      width = 2.05;
      length = 4.55;
      bodyH = 0.74;
      cabinH = 0.66;
      cabinL = 2.65;
    } else if (type === 'truck') {
      width = 2.25;
      length = 6.2;
      bodyH = 1.95;
      cabinH = 0;
    } else if (type === 'coupe') {
      width = 1.96;
      length = 4.2;
      bodyH = 0.54;
      cabinH = 0.44;
      cabinL = 1.85;
    }

    if (type === 'truck') {
      // Cargo box
      const cargo = new THREE.Mesh(
        new THREE.BoxGeometry(width, 1.9, length * 0.72),
        new THREE.MeshStandardMaterial({ color: 0xe9edf5, roughness: 0.6 })
      );
      cargo.position.set(0, 1.32, 0.75);
      cargo.castShadow = true;
      cargo.receiveShadow = true;
      group.add(cargo);

      // Cab
      const cab = new THREE.Mesh(new THREE.BoxGeometry(width * 0.94, 1.35, 1.65), paintMat);
      cab.position.set(0, 1.05, -2.05);
      cab.castShadow = true;
      group.add(cab);

      const windshield = new THREE.Mesh(new THREE.BoxGeometry(width * 0.84, 0.56, 0.12), glassMat);
      windshield.position.set(0, 1.32, -2.86);
      group.add(windshield);
    } else {
      const body = new THREE.Mesh(new THREE.BoxGeometry(width, bodyH, length), paintMat);
      body.position.set(0, 0.34 + bodyH / 2, 0);
      body.castShadow = true;
      body.receiveShadow = true;
      group.add(body);

      const cabin = new THREE.Mesh(new THREE.BoxGeometry(width * 0.82, cabinH, cabinL), glassMat);
      cabin.position.set(0, 0.34 + bodyH + cabinH / 2 - 0.04, 0.18);
      cabin.castShadow = true;
      group.add(cabin);

      const roof = new THREE.Mesh(new THREE.BoxGeometry(width * 0.78, 0.07, cabinL * 0.8), paintMat);
      roof.position.set(0, 0.34 + bodyH + cabinH - 0.02, 0.18);
      group.add(roof);
    }

    // Taillights & Headlights
    const tailMat = new THREE.MeshBasicMaterial({ color: 0xff2222 });
    const headMat = new THREE.MeshBasicMaterial({ color: 0xfff4d4 });
    [-width * 0.34, width * 0.34].forEach((lx) => {
      const tl = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.12, 0.08), tailMat);
      tl.position.set(lx, 0.72, length / 2 + 0.02);
      group.add(tl);

      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.12, 0.08), headMat);
      hl.position.set(lx, 0.68, -length / 2 - 0.02);
      group.add(hl);
    });

    // Wheels
    const wGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.24, 12);
    wGeo.rotateZ(Math.PI / 2);
    [
      [-width * 0.48, -length * 0.31],
      [width * 0.48, -length * 0.31],
      [-width * 0.48, length * 0.31],
      [width * 0.48, length * 0.31],
    ].forEach((wp) => {
      const wheel = new THREE.Mesh(wGeo, darkMat);
      wheel.position.set(wp[0], 0.36, wp[1]);
      group.add(wheel);
    });

    group.userData = { halfWidth: width * 0.48, halfLength: length * 0.48 };
    return group;
  }

  function createCoinMesh() {
    const group = new THREE.Group();
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xffd23f,
      emissive: 0x6b4b00,
      emissiveIntensity: 0.45,
      roughness: 0.2,
      metalness: 0.85,
    });
    const coreMat = new THREE.MeshBasicMaterial({ color: 0xe10600 });

    const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.58, 0.14, 18), goldMat);
    disc.rotation.x = Math.PI / 2;
    group.add(disc);

    const inner = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.16, 12), coreMat);
    inner.rotation.x = Math.PI / 2;
    group.add(inner);

    return group;
  }

  function createTreeMesh() {
    const tree = new THREE.Group();
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.34, 2.2, 7),
      new THREE.MeshStandardMaterial({ color: 0x4b3322, roughness: 0.9 })
    );
    trunk.position.y = 1.1;
    trunk.castShadow = true;
    tree.add(trunk);

    const leafMat = new THREE.MeshStandardMaterial({
      color: 0x1d6b3b,
      roughness: 0.82,
    });
    const c1 = new THREE.Mesh(new THREE.ConeGeometry(1.65, 3.2, 8), leafMat);
    c1.position.y = 3.2;
    c1.castShadow = true;
    tree.add(c1);

    const c2 = new THREE.Mesh(new THREE.ConeGeometry(1.22, 2.6, 8), leafMat);
    c2.position.y = 4.7;
    c2.castShadow = true;
    tree.add(c2);

    return tree;
  }

  function createBuildingMesh(width, height, depth, variant) {
    const tex = getBuildingTexture(variant);
    const sideMat = new THREE.MeshStandardMaterial({
      map: tex,
      roughness: 0.45,
      metalness: 0.25,
    });
    const roofMat = new THREE.MeshStandardMaterial({
      color: 0x12141b,
      roughness: 0.8,
    });

    const building = new THREE.Mesh(
      new THREE.BoxGeometry(width, height, depth),
      [sideMat, sideMat, roofMat, roofMat, sideMat, sideMat]
    );
    building.position.y = height / 2;
    building.receiveShadow = true;
    return building;
  }

  function createMountainMesh(radius, height) {
    const geo = new THREE.ConeGeometry(radius, height, 6);
    const mat = new THREE.MeshStandardMaterial({
      color: 0x1e2230,
      roughness: 0.95,
      flatShading: true,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.y = height / 2 - 1;
    return mesh;
  }

  global.FossaModels = {
    getRoadTexture,
    createPlayerCar,
    createTrafficCar,
    createCoinMesh,
    createTreeMesh,
    createBuildingMesh,
    createMountainMesh,
  };
})(window);
