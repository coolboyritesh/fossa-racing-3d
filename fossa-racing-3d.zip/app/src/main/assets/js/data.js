(function (global) {
  'use strict';

  const PAINT_PALETTE = [
    { id: 'crimson', name: 'Fossa Red', hex: 0xe10600, css: '#e10600' },
    { id: 'pearl', name: 'Arctic White', hex: 0xf4f5f7, css: '#f4f5f7' },
    { id: 'obsidian', name: 'Obsidian Black', hex: 0x1a1c22, css: '#1a1c22' },
    { id: 'cobalt', name: 'Apex Blue', hex: 0x0066ff, css: '#0066ff' },
    { id: 'solar', name: 'Solar Gold', hex: 0xffb800, css: '#ffb800' },
    { id: 'titanium', name: 'Titanium Silver', hex: 0x8e95a5, css: '#8e95a5' },
  ];

  const CARS = [
    {
      id: 'fossa_gtr',
      name: 'FOSSA GT-R',
      tier: 'STREET SPEC',
      price: 0,
      defaultColor: 0xe10600,
      topSpeedKmh: 255,
      accelStat: 74,
      handlingStat: 80,
      nitroStat: 75,
      // Physics tuning
      maxSpeed: 72,       // world units/s (~255 km/h display)
      accelRate: 30,
      steerSpeed: 13.5,
      nitroBoost: 1.28,
      nitroDrain: 24,
      wingType: 'gt',
      exhausts: 2,
      bodyScale: [1.0, 1.0, 1.0],
    },
    {
      id: 'vipera_apex',
      name: 'VIPERA APEX',
      tier: 'TRACK COUPE',
      price: 350,
      defaultColor: 0xf4f5f7,
      topSpeedKmh: 280,
      accelStat: 81,
      handlingStat: 86,
      nitroStat: 80,
      maxSpeed: 79,
      accelRate: 34,
      steerSpeed: 15.0,
      nitroBoost: 1.30,
      nitroDrain: 22,
      wingType: 'ducktail',
      exhausts: 2,
      bodyScale: [1.04, 0.96, 1.02],
    },
    {
      id: 'kurogane_v8',
      name: 'KUROGANE V8',
      tier: 'SUPER GT',
      price: 750,
      defaultColor: 0x1a1c22,
      topSpeedKmh: 305,
      accelStat: 87,
      handlingStat: 84,
      nitroStat: 88,
      maxSpeed: 86,
      accelRate: 38,
      steerSpeed: 14.8,
      nitroBoost: 1.33,
      nitroDrain: 20,
      wingType: 'gt_tall',
      exhausts: 4,
      bodyScale: [1.06, 0.94, 1.06],
    },
    {
      id: 'scarlet_demon',
      name: 'SCARLET DEMON',
      tier: 'HYPERCAR',
      price: 1400,
      defaultColor: 0xe10600,
      topSpeedKmh: 332,
      accelStat: 93,
      handlingStat: 90,
      nitroStat: 92,
      maxSpeed: 93,
      accelRate: 43,
      steerSpeed: 16.0,
      nitroBoost: 1.35,
      nitroDrain: 18,
      wingType: 'swan',
      exhausts: 4,
      bodyScale: [1.08, 0.90, 1.08],
    },
    {
      id: 'phantom_proto',
      name: 'PHANTOM X-9',
      tier: 'PROTOTYPE',
      price: 2400,
      defaultColor: 0x0066ff,
      topSpeedKmh: 365,
      accelStat: 98,
      handlingStat: 96,
      nitroStat: 98,
      maxSpeed: 102,
      accelRate: 48,
      steerSpeed: 17.2,
      nitroBoost: 1.38,
      nitroDrain: 16,
      wingType: 'f1',
      exhausts: 4,
      bodyScale: [1.10, 0.86, 1.12],
    },
  ];

  const MISSIONS = [
    {
      id: 'm1',
      number: 'MISSION 01',
      title: 'CITY SPRINT',
      description: 'Reach 1.10 km within 55s through light downtown traffic.',
      atmosphere: 'dusk',
      targetDistanceKm: 1.10,
      timeLimitSec: 55,
      targetCoins: 0,
      maxCollisions: 3,
      trafficDensity: 0.55,
      rewardCoins: 180,
    },
    {
      id: 'm2',
      number: 'MISSION 02',
      title: 'GOLD RUSH',
      description: 'Collect 22 Fossa Coins and cover 1.30 km before time runs out.',
      atmosphere: 'day',
      targetDistanceKm: 1.30,
      timeLimitSec: 65,
      targetCoins: 22,
      maxCollisions: 3,
      trafficDensity: 0.72,
      rewardCoins: 260,
    },
    {
      id: 'm3',
      number: 'MISSION 03',
      title: 'CLEAN APEX',
      description: 'Travel 1.65 km within 65s with at most 1 traffic collision.',
      atmosphere: 'dusk',
      targetDistanceKm: 1.65,
      timeLimitSec: 65,
      targetCoins: 0,
      maxCollisions: 1,
      trafficDensity: 0.85,
      rewardCoins: 340,
    },
    {
      id: 'm4',
      number: 'MISSION 04',
      title: 'NIGHTFALL NITRO',
      description: 'Push past 2.00 km in 70s on the illuminated midnight highway.',
      atmosphere: 'night',
      targetDistanceKm: 2.00,
      timeLimitSec: 70,
      targetCoins: 15,
      maxCollisions: 3,
      trafficDensity: 0.95,
      rewardCoins: 440,
    },
    {
      id: 'm5',
      number: 'MISSION 05',
      title: 'REDLINE RUSH',
      description: 'Collect 32 coins and reach 2.40 km within 78s.',
      atmosphere: 'day',
      targetDistanceKm: 2.40,
      timeLimitSec: 78,
      targetCoins: 32,
      maxCollisions: 2,
      trafficDensity: 1.05,
      rewardCoins: 560,
    },
    {
      id: 'm6',
      number: 'MISSION 06',
      title: 'FOSSA FINALE',
      description: 'Conquer 3.00 km in 88s through heavy high-speed expressway traffic.',
      atmosphere: 'night',
      targetDistanceKm: 3.00,
      timeLimitSec: 88,
      targetCoins: 25,
      maxCollisions: 2,
      trafficDensity: 1.2,
      rewardCoins: 800,
    },
  ];

  const DEFAULT_SAVE = {
    coins: 250,
    unlockedCars: ['fossa_gtr'],
    equippedCarId: 'fossa_gtr',
    carColors: {
      fossa_gtr: 0xe10600,
      vipera_apex: 0xf4f5f7,
      kurogane_v8: 0x1a1c22,
      scarlet_demon: 0xe10600,
      phantom_proto: 0x0066ff,
    },
    missionStars: {}, // e.g. { m1: 3 }
    bestDistanceKm: 0,
    soundEnabled: true,
    highQuality: true,
  };

  function loadSave() {
    let raw = '';
    try {
      if (global.FossaAndroid && typeof global.FossaAndroid.loadProgress === 'function') {
        raw = global.FossaAndroid.loadProgress();
      }
    } catch (_) {}
    if (!raw) {
      try {
        raw = global.localStorage.getItem('fossa_racing_save_v1') || '';
      } catch (_) {}
    }
    if (!raw) return JSON.parse(JSON.stringify(DEFAULT_SAVE));
    try {
      const parsed = JSON.parse(raw);
      return Object.assign(JSON.parse(JSON.stringify(DEFAULT_SAVE)), parsed, {
        carColors: Object.assign({}, DEFAULT_SAVE.carColors, parsed.carColors || {}),
        missionStars: Object.assign({}, parsed.missionStars || {}),
      });
    } catch (_) {
      return JSON.parse(JSON.stringify(DEFAULT_SAVE));
    }
  }

  function persistSave(save) {
    const json = JSON.stringify(save);
    try {
      global.localStorage.setItem('fossa_racing_save_v1', json);
    } catch (_) {}
    try {
      if (global.FossaAndroid && typeof global.FossaAndroid.saveProgress === 'function') {
        global.FossaAndroid.saveProgress(json);
      }
    } catch (_) {}
  }

  global.FossaData = {
    PAINT_PALETTE,
    CARS,
    MISSIONS,
    loadSave,
    persistSave,
    getCarById(id) {
      return CARS.find((c) => c.id === id) || CARS[0];
    },
    getMissionById(id) {
      return MISSIONS.find((m) => m.id === id) || null;
    },
    isMissionUnlocked(index, save) {
      if (index === 0) return true;
      const prev = MISSIONS[index - 1];
      return (save.missionStars[prev.id] || 0) > 0;
    },
  };
})(window);
