(function (global) {
  'use strict';

  /**
   * Android AdMob JavaScript Bridge:
   * - In Android native builds, routes directly to Kotlin `GoogleAdMobController`
   *   which uses Google test IDs in `debug` builds and production IDs in `release` builds.
   * - In Capacitor testing shells, uses Google test IDs only (`isTesting: true`).
   */
  const DEV_TEST_AD_IDS = {
    banner: 'ca-app-pub-3940256099942544/6300978111',
    interstitial: 'ca-app-pub-3940256099942544/1033173712',
    rewarded: 'ca-app-pub-3940256099942544/5224354917',
  };

  const REWARD_COINS_AMOUNT = 500;
  const INTERSTITIAL_MIN_INTERVAL_MS = 90000;

  const pendingCallbacks = {};
  let capacitorInitialized = false;
  let completedRaceCount = 0;
  let lastInterstitialTs = 0;

  global.onNativeAdResult = function (format, placement, shown, rewarded, rewardAmount, message) {
    const key = format + ':' + placement;
    const cb = pendingCallbacks[key];
    if (typeof cb === 'function') {
      delete pendingCallbacks[key];
      cb({
        format,
        placement,
        shown: !!shown,
        rewarded: !!rewarded,
        rewardAmount: rewarded ? Number(rewardAmount || 0) : 0,
        message: message || '',
      });
    }
  };

  function hasNativeBridge() {
    return typeof global.FossaAndroid === 'object' && global.FossaAndroid !== null;
  }

  function getCapacitorAdMob() {
    return global.Capacitor &&
      global.Capacitor.Plugins &&
      global.Capacitor.Plugins.AdMob
      ? global.Capacitor.Plugins.AdMob
      : null;
  }

  async function ensureCapacitorInit() {
    const capAdMob = getCapacitorAdMob();
    if (!capAdMob || capacitorInitialized) return capAdMob;
    try {
      await capAdMob.initialize({
        requestTrackingAuthorization: false,
        initializeForTesting: true,
      });
      capacitorInitialized = true;
    } catch (_) {}
    return capAdMob;
  }

  const FossaAdHooks = {
    REWARD_COINS_AMOUNT,

    isNativeSdkLinked() {
      try {
        if (hasNativeBridge() && typeof global.FossaAndroid.isNativeAdSdkLinked === 'function') {
          return !!global.FossaAndroid.isNativeAdSdkLinked();
        }
      } catch (_) {}
      return !!getCapacitorAdMob();
    },

    notifyScreen(screenName) {
      try {
        if (hasNativeBridge() && typeof global.FossaAndroid.notifyScreenChanged === 'function') {
          global.FossaAndroid.notifyScreenChanged(screenName);
        }
      } catch (_) {}

      const capAdMob = getCapacitorAdMob();
      if (capAdMob) {
        ensureCapacitorInit().then((adMob) => {
          if (!adMob) return;
          if (screenName === 'MENU') {
            adMob
              .showBanner({
                adId: DEV_TEST_AD_IDS.banner,
                adSize: 'BANNER',
                position: 'BOTTOM_CENTER',
                isTesting: true,
              })
              .catch(() => {});
          } else {
            adMob.hideBanner().catch(() => {});
          }
        });
      }
    },

    preloadPostRaceInterstitial() {
      try {
        if (hasNativeBridge() && typeof global.FossaAndroid.preloadAd === 'function') {
          global.FossaAndroid.preloadAd('INTERSTITIAL', 'post_race_interstitial');
        }
      } catch (_) {}

      const capAdMob = getCapacitorAdMob();
      if (capAdMob) {
        ensureCapacitorInit().then((adMob) => {
          if (adMob) {
            adMob
              .prepareInterstitial({ adId: DEV_TEST_AD_IDS.interstitial, isTesting: true })
              .catch(() => {});
          }
        });
      }
    },

    preloadRewarded() {
      try {
        if (hasNativeBridge() && typeof global.FossaAndroid.preloadAd === 'function') {
          global.FossaAndroid.preloadAd('REWARDED', 'bonus_500_coins_rewarded');
        }
      } catch (_) {}

      const capAdMob = getCapacitorAdMob();
      if (capAdMob) {
        ensureCapacitorInit().then((adMob) => {
          if (adMob) {
            adMob
              .prepareRewardVideoAd({ adId: DEV_TEST_AD_IDS.rewarded, isTesting: true })
              .catch(() => {});
          }
        });
      }
    },

    requestPostRaceInterstitial(onComplete) {
      completedRaceCount += 1;
      const now = Date.now();
      // Frequency cap: every 2nd completed race AND at least 90s between interstitials
      if (completedRaceCount % 2 !== 0 || now - lastInterstitialTs < INTERSTITIAL_MIN_INTERVAL_MS) {
        if (typeof onComplete === 'function') {
          onComplete({ shown: false, rewarded: false, rewardAmount: 0, message: 'Frequency cap' });
        }
        return;
      }

      if (hasNativeBridge() && this.isNativeSdkLinked()) {
        pendingCallbacks['interstitial:post_race_interstitial'] = (res) => {
          if (res && res.shown) lastInterstitialTs = Date.now();
          if (typeof onComplete === 'function') onComplete(res);
        };
        global.FossaAndroid.showInterstitial('post_race_interstitial');
        return;
      }

      const capAdMob = getCapacitorAdMob();
      if (capAdMob) {
        ensureCapacitorInit()
          .then((adMob) => adMob.showInterstitial())
          .then(() => {
            lastInterstitialTs = Date.now();
            onComplete && onComplete({ shown: true, rewarded: false, rewardAmount: 0 });
          })
          .catch(() => onComplete && onComplete({ shown: false, rewarded: false, rewardAmount: 0 }));
        return;
      }

      if (typeof onComplete === 'function') {
        onComplete({ shown: false, rewarded: false, rewardAmount: 0 });
      }
    },

    requestRewarded500Coins(onComplete) {
      const placementKey = 'bonus_500_coins_rewarded';

      if (hasNativeBridge() && this.isNativeSdkLinked()) {
        pendingCallbacks['rewarded:' + placementKey] = onComplete;
        global.FossaAndroid.showRewarded(placementKey);
        return;
      }

      const capAdMob = getCapacitorAdMob();
      if (capAdMob) {
        ensureCapacitorInit()
          .then((adMob) => adMob.showRewardVideoAd())
          .then((rewardItem) => {
            const verified = !!(rewardItem && (rewardItem.amount > 0 || rewardItem.type));
            onComplete &&
              onComplete({
                shown: true,
                rewarded: verified,
                rewardAmount: verified ? REWARD_COINS_AMOUNT : 0,
                message: verified ? 'Verified +500 coins' : 'Reward not verified',
              });
          })
          .catch(() => {
            onComplete &&
              onComplete({
                shown: false,
                rewarded: false,
                rewardAmount: 0,
                message: 'Rewarded ad unavailable',
              });
          });
        return;
      }

      if (typeof onComplete === 'function') {
        onComplete({
          shown: false,
          rewarded: false,
          rewardAmount: 0,
          message: 'Ad SDK unavailable',
        });
      }
    },
  };

  global.FossaAdHooks = FossaAdHooks;
})(window);
