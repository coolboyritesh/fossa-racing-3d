(function (global) {
  'use strict';

  const ROAD_WIDTH = 16;
  const LANE_X = [-5.4, -1.8, 1.8, 5.4];
  const BARRIER_LIMIT = 6.75;
  const CHUNK_LEN = 60;
  const CHUNK_COUNT = 8;

  const ATMOSPHERES = {
    dusk: {
      sky: 0x160e18,
      fog: 0x18101c,
      fogDensity: 0.0052,
      hemiSky: 0xff9f80,
      hemiGround: 0x191b26,
      hemiInt: 0.85,
      sunColor: 0xffb38a,
      sunInt: 1.5,
    },
    day: {
      sky: 0x2a486b,
      fog: 0x355375,
      fogDensity: 0.0042,
      hemiSky: 0xdff1ff,
      hemiGround: 0x263238,
      hemiInt: 1.0,
      sunColor: 0xfff5e4,
      sunInt: 1.75,
    },
    night: {
      sky: 0x070910,
      fog: 0x090b14,
      fogDensity: 0.0062,
      hemiSky: 0x45608a,
      hemiGround: 0x0c0e14,
      hemiInt: 0.72,
      sunColor: 0x9bbdff,
      sunInt: 1.15,
    },
  };

  class FossaEngine {
    constructor(canvas, callbacks) {
      this.canvas = canvas;
      this.cb = callbacks || {};

      this.renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        powerPreference: 'high-performance',
      });
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.12;

      this.scene = new THREE.Scene();
      this.camera = new THREE.PerspectiveCamera(62, 16 / 9, 0.5, 460);

      // Lighting
      this.hemiLight = new THREE.HemisphereLight(0xff9f80, 0x191b26, 0.85);
      this.scene.add(this.hemiLight);

      this.sunLight = new THREE.DirectionalLight(0xfff0dd, 1.5);
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.set(1024, 1024);
      this.sunLight.shadow.camera.near = 2;
      this.sunLight.shadow.camera.far = 120;
      const d = 26;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
      this.scene.add(this.sunLight);
      this.scene.add(this.sunLight.target);

      // Groups
      this.worldGroup = new THREE.Group();
      this.showroomGroup = new THREE.Group();
      this.scene.add(this.worldGroup);
      this.scene.add(this.showroomGroup);

      this.chunks = [];
      this.trafficPool = [];
      this.coins = [];
      this.particles = [];

      this.mode = 'SHOWROOM'; // SHOWROOM | RACE
      this.highQuality = true;
      this.turntableAngle = 0.65;
      this.showroomCar = null;
      this.playerCar = null;

      this.resetRaceState();
      this.buildShowroom();
      this.buildWorldChunks();
      this.buildParticles();
      this.applyAtmosphere('dusk');
      this.resize();
    }

    setQuality(isHigh) {
      this.highQuality = !!isHigh;
      const maxDpr = this.highQuality ? Math.min(window.devicePixelRatio || 1, 2) : 1;
      this.renderer.setPixelRatio(maxDpr);
      this.renderer.shadowMap.enabled = this.highQuality;
      this.resize();
    }

    resize() {
      const w = window.innerWidth || 800;
      const h = window.innerHeight || 450;
      const maxDpr = this.highQuality ? Math.min(window.devicePixelRatio || 1, 2) : 1;
      this.renderer.setPixelRatio(maxDpr);
      this.renderer.setSize(w, h, false);
      this.camera.aspect = w / Math.max(1, h);
      this.camera.updateProjectionMatrix();
    }

    applyAtmosphere(name) {
      const a = ATMOSPHERES[name] || ATMOSPHERES.dusk;
      this.scene.background = new THREE.Color(a.sky);
      this.scene.fog = new THREE.FogExp2(a.fog, a.fogDensity);
      this.hemiLight.color.setHex(a.hemiSky);
      this.hemiLight.groundColor.setHex(a.hemiGround);
      this.hemiLight.intensity = a.hemiInt;
      this.sunLight.color.setHex(a.sunColor);
      this.sunLight.intensity = a.sunInt;
    }

    buildShowroom() {
      const podium = new THREE.Mesh(
        new THREE.CylinderGeometry(4.2, 4.5, 0.35, 36),
        new THREE.MeshStandardMaterial({ color: 0x14151c, roughness: 0.35, metalness: 0.6 })
      );
      podium.position.y = -0.18;
      podium.receiveShadow = true;
      this.showroomGroup.add(podium);

      const ring = new THREE.Mesh(
        new THREE.RingGeometry(4.18, 4.35, 48),
        new THREE.MeshBasicMaterial({ color: 0xe10600, side: THREE.DoubleSide })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.01;
      this.showroomGroup.add(ring);

      const floor = new THREE.Mesh(
        new THREE.CircleGeometry(28, 32),
        new THREE.MeshStandardMaterial({ color: 0x0b0b10, roughness: 0.85, metalness: 0.2 })
      );
      floor.rotation.x = -Math.PI / 2;
      floor.position.y = -0.35;
      floor.receiveShadow = true;
      this.showroomGroup.add(floor);
    }

    setShowroomCar(carSpec, paintHex) {
      if (this.showroomCar) {
        this.showroomGroup.remove(this.showroomCar.group);
      }
      this.showroomCar = global.FossaModels.createPlayerCar(carSpec, paintHex);
      this.showroomCar.group.position.set(0, 0, 0);
      this.showroomGroup.add(this.showroomCar.group);
    }

    rotateShowroom(deltaYaw) {
      this.turntableAngle += deltaYaw;
    }

    enterShowroomMode(carSpec, paintHex) {
      this.mode = 'SHOWROOM';
      this.worldGroup.visible = false;
      this.showroomGroup.visible = true;
      this.applyAtmosphere('night');
      this.setShowroomCar(carSpec, paintHex);
      this.camera.fov = 48;
      this.camera.updateProjectionMatrix();
      this.sunLight.position.set(8, 12, 8);
      this.sunLight.target.position.set(0, 0.5, 0);
    }

    buildWorldChunks() {
      const roadTex = global.FossaModels.getRoadTexture();
      const roadMat = new THREE.MeshStandardMaterial({
        map: roadTex,
        roughness: 0.72,
        metalness: 0.12,
      });
      const groundMat = new THREE.MeshStandardMaterial({
        color: 0x152018,
        roughness: 0.95,
      });
      const barrierMat = new THREE.MeshStandardMaterial({
        color: 0xcfd4de,
        roughness: 0.4,
        metalness: 0.5,
      });
      const postMat = new THREE.MeshBasicMaterial({ color: 0xe10600 });
      const gantryMat = new THREE.MeshStandardMaterial({ color: 0x20232d, metalness: 0.7, roughness: 0.35 });
      const bannerMat = new THREE.MeshBasicMaterial({ color: 0xe10600 });

      for (let i = 0; i < CHUNK_COUNT; i++) {
        const chunk = new THREE.Group();

        // Ground desert/grass plains
        const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, CHUNK_LEN), groundMat);
        ground.rotation.x = -Math.PI / 2;
        ground.position.y = -0.04;
        ground.receiveShadow = true;
        chunk.add(ground);

        // 4-lane asphalt road
        const road = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_WIDTH, CHUNK_LEN), roadMat);
        road.rotation.x = -Math.PI / 2;
        road.receiveShadow = true;
        chunk.add(road);

        // Left & Right highway crash barriers + red reflector posts
        [-ROAD_WIDTH / 2 - 0.55, ROAD_WIDTH / 2 + 0.55].forEach((bx) => {
          const rail = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.75, CHUNK_LEN), barrierMat);
          rail.position.set(bx, 0.42, 0);
          rail.castShadow = true;
          rail.receiveShadow = true;
          chunk.add(rail);

          for (let pz = -CHUNK_LEN / 2 + 6; pz < CHUNK_LEN / 2; pz += 12) {
            const post = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.18, 0.42), postMat);
            post.position.set(bx, 0.85, pz);
            chunk.add(post);
          }
        });

        // Trees along outer parkway
        for (let tz = -CHUNK_LEN / 2 + 8; tz < CHUNK_LEN / 2; tz += 18) {
          [-1, 1].forEach((side) => {
            if (Math.random() > 0.25) {
              const tree = global.FossaModels.createTreeMesh();
              const sc = 0.85 + Math.random() * 0.45;
              tree.scale.set(sc, sc, sc);
              tree.position.set(side * (10.8 + Math.random() * 2.2), 0, tz + (Math.random() - 0.5) * 4);
              chunk.add(tree);
            }
          });
        }

        // City skyline buildings on both sides
        for (let bz = -CHUNK_LEN / 2 + 12; bz < CHUNK_LEN / 2; bz += 26) {
          [-1, 1].forEach((side) => {
            const bw = 9 + Math.random() * 6;
            const bd = 12 + Math.random() * 8;
            const bh = 18 + Math.random() * 38;
            const bldg = global.FossaModels.createBuildingMesh(bw, bh, bd, i + Math.floor(Math.random() * 3));
            bldg.position.x = side * (19 + bw / 2 + Math.random() * 6);
            bldg.position.z = bz;
            chunk.add(bldg);
          });
        }

        // Distant mountains
        if (i % 2 === 0) {
          [-1, 1].forEach((side) => {
            const mtn = global.FossaModels.createMountainMesh(34 + Math.random() * 14, 38 + Math.random() * 28);
            mtn.position.x = side * (78 + Math.random() * 22);
            mtn.position.z = (Math.random() - 0.5) * 20;
            chunk.add(mtn);
          });
        }

        // Overhead highway sign gantry every 2nd chunk
        if (i % 2 === 1) {
          const leftPillar = new THREE.Mesh(new THREE.BoxGeometry(0.5, 6.8, 0.5), gantryMat);
          leftPillar.position.set(-ROAD_WIDTH / 2 - 0.8, 3.4, 0);
          chunk.add(leftPillar);

          const rightPillar = new THREE.Mesh(new THREE.BoxGeometry(0.5, 6.8, 0.5), gantryMat);
          rightPillar.position.set(ROAD_WIDTH / 2 + 0.8, 3.4, 0);
          chunk.add(rightPillar);

          const crossBeam = new THREE.Mesh(new THREE.BoxGeometry(ROAD_WIDTH + 2.2, 0.55, 0.55), gantryMat);
          crossBeam.position.set(0, 6.6, 0);
          chunk.add(crossBeam);

          const sign = new THREE.Mesh(new THREE.BoxGeometry(8.5, 1.35, 0.2), bannerMat);
          sign.position.set(0, 6.6, 0.3);
          chunk.add(sign);
        }

        chunk.position.z = -i * CHUNK_LEN;
        this.worldGroup.add(chunk);
        this.chunks.push(chunk);
      }
    }

    buildParticles() {
      const geo = new THREE.BoxGeometry(0.24, 0.24, 0.24);
      for (let i = 0; i < 36; i++) {
        const mat = new THREE.MeshBasicMaterial({ color: 0xffd23f, transparent: true, opacity: 1 });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.visible = false;
        this.worldGroup.add(mesh);
        this.particles.push({ mesh, vx: 0, vy: 0, vz: 0, life: 0 });
      }
    }

    spawnBurst(x, y, z, colorHex, count) {
      let spawned = 0;
      for (let i = 0; i < this.particles.length && spawned < count; i++) {
        const p = this.particles[i];
        if (p.life <= 0) {
          p.mesh.material.color.setHex(colorHex);
          p.mesh.material.opacity = 1;
          p.mesh.position.set(x, y, z);
          p.mesh.visible = true;
          p.vx = (Math.random() - 0.5) * 14;
          p.vy = 3 + Math.random() * 8;
          p.vz = (Math.random() - 0.5) * 14;
          p.life = 0.45 + Math.random() * 0.25;
          spawned++;
        }
      }
    }

    clearDynamicEntities() {
      this.trafficPool.forEach((t) => this.worldGroup.remove(t.mesh));
      this.trafficPool = [];
      this.coins.forEach((c) => this.worldGroup.remove(c.mesh));
      this.coins = [];
      this.particles.forEach((p) => {
        p.life = 0;
        p.mesh.visible = false;
      });
    }

    resetRaceState() {
      this.race = {
        active: false,
        paused: false,
        carSpec: null,
        mission: null,
        playerX: 0,
        playerZ: 0,
        speed: 0,
        steerAngle: 0,
        nitro: 100,
        isNitroActive: false,
        elapsedSec: 0,
        distanceMeters: 0,
        coinsCollected: 0,
        collisions: 0,
        maxShields: 3,
        shieldsLeft: 3,
        invulnTimer: 0,
        shakeTimer: 0,
        topSpeedKmh: 0,
        nextCoinSpawnZ: -60,
        nearMissBonusCooldown: 0,
      };
    }

    startRace(carSpec, paintHex, mission) {
      this.mode = 'RACE';
      this.showroomGroup.visible = false;
      this.worldGroup.visible = true;
      this.clearDynamicEntities();
      this.resetRaceState();

      if (this.playerCar) {
        this.worldGroup.remove(this.playerCar.group);
      }
      this.playerCar = global.FossaModels.createPlayerCar(carSpec, paintHex);
      this.playerCar.group.position.set(0, 0, 0);
      this.worldGroup.add(this.playerCar.group);

      // Reset chunk positions
      for (let i = 0; i < this.chunks.length; i++) {
        this.chunks[i].position.z = -i * CHUNK_LEN;
      }

      const atmos = mission ? mission.atmosphere : 'dusk';
      this.applyAtmosphere(atmos);

      this.race.carSpec = carSpec;
      this.race.mission = mission;
      this.race.maxShields = mission ? mission.maxCollisions : 3;
      this.race.shieldsLeft = this.race.maxShields;
      this.race.active = true;
      this.race.paused = true; // Held during 3-2-1 countdown

      // Spawn initial traffic ahead
      const density = mission ? mission.trafficDensity : 0.85;
      const trafficCount = Math.round(11 * density);
      for (let i = 0; i < trafficCount; i++) {
        this.spawnTrafficCar(-75 - i * 32 - Math.random() * 14);
      }

      // Spawn initial coin line
      this.spawnCoinWave(-55);
      this.race.nextCoinSpawnZ = -125;

      // Place camera immediately behind car
      this.camera.fov = 62;
      this.camera.updateProjectionMatrix();
      this.camera.position.set(0, 3.6, 8.8);
      this.camera.lookAt(0, 1.3, -14);
    }

    setRacePaused(paused) {
      this.race.paused = !!paused;
    }

    spawnTrafficCar(zPos) {
      const types = ['sedan', 'suv', 'coupe', 'truck'];
      const colors = [0xd8dde8, 0x2f3b52, 0xb82424, 0xe8a815, 0x265c4b, 0x454a57];
      const type = types[Math.floor(Math.random() * types.length)];
      const color = colors[Math.floor(Math.random() * colors.length)];
      const mesh = global.FossaModels.createTrafficCar(type, color);

      const laneIdx = this.pickSafeLane(zPos);
      mesh.position.set(LANE_X[laneIdx], 0, zPos);
      this.worldGroup.add(mesh);

      const baseSpeed = type === 'truck' ? 19 + Math.random() * 5 : 23 + Math.random() * 11;
      this.trafficPool.push({
        mesh,
        laneIdx,
        speed: baseSpeed,
        passedNearMiss: false,
      });
    }

    pickSafeLane(targetZ) {
      // Ensure we never block all 4 lanes within 24m of targetZ
      const occupied = new Set();
      for (let i = 0; i < this.trafficPool.length; i++) {
        const t = this.trafficPool[i];
        if (Math.abs(t.mesh.position.z - targetZ) < 24) {
          occupied.add(t.laneIdx);
        }
      }
      const candidates = [0, 1, 2, 3].filter((l) => !occupied.has(l));
      if (candidates.length <= 1) {
        return Math.floor(Math.random() * 4);
      }
      return candidates[Math.floor(Math.random() * candidates.length)];
    }

    spawnCoinWave(startZ) {
      const lane = Math.floor(Math.random() * 4);
      const targetLane = Math.max(0, Math.min(3, lane + (Math.random() > 0.5 ? 1 : -1)));
      const count = 5;
      for (let i = 0; i < count; i++) {
        const t = i / (count - 1);
        const x = LANE_X[lane] * (1 - t) + LANE_X[targetLane] * t;
        const z = startZ - i * 8.5;
        const mesh = global.FossaModels.createCoinMesh();
        mesh.position.set(x, 1.0, z);
        this.worldGroup.add(mesh);
        this.coins.push({ mesh, collected: false });
      }
    }

    update(dt, input) {
      const clampedDt = Math.min(dt, 0.05);

      if (this.mode === 'SHOWROOM') {
        this.turntableAngle += clampedDt * 0.45;
        if (this.showroomCar) {
          this.showroomCar.group.rotation.y = this.turntableAngle;
        }
        this.camera.position.set(0, 2.25, 6.4);
        this.camera.lookAt(0, 0.85, 0);
        this.renderer.render(this.scene, this.camera);
        return null;
      }

      const r = this.race;
      if (!r.active || !this.playerCar) {
        this.renderer.render(this.scene, this.camera);
        return null;
      }

      if (!r.paused) {
        this.stepRacePhysics(clampedDt, input);
      }

      this.updateCamera(clampedDt);
      this.renderer.render(this.scene, this.camera);

      const kmh = Math.max(0, Math.round(r.speed * 3.55));
      if (kmh > r.topSpeedKmh) r.topSpeedKmh = kmh;

      return {
        speedKmh: kmh,
        maxSpeedKmh: r.carSpec.topSpeedKmh,
        nitro: r.nitro,
        isNitroActive: r.isNitroActive,
        elapsedSec: r.elapsedSec,
        distanceKm: r.distanceMeters / 1000,
        coinsCollected: r.coinsCollected,
        collisions: r.collisions,
        shieldsLeft: r.shieldsLeft,
        maxShields: r.maxShields,
        speedRatio: Math.min(1, Math.abs(r.speed) / r.carSpec.maxSpeed),
      };
    }

    stepRacePhysics(dt, input) {
      const r = this.race;
      const spec = r.carSpec;
      r.elapsedSec += dt;
      if (r.invulnTimer > 0) r.invulnTimer = Math.max(0, r.invulnTimer - dt);
      if (r.shakeTimer > 0) r.shakeTimer = Math.max(0, r.shakeTimer - dt);
      if (r.nearMissBonusCooldown > 0) r.nearMissBonusCooldown -= dt;

      // Nitro activation
      const wantsNitro = !!input.nitro && r.nitro > 4 && (input.accel || r.speed > 18);
      r.isNitroActive = wantsNitro;
      if (r.isNitroActive) {
        r.nitro = Math.max(0, r.nitro - spec.nitroDrain * dt);
      } else {
        r.nitro = Math.min(100, r.nitro + (r.speed > 20 ? 4.5 : 1.5) * dt);
      }

      // Forward Acceleration / Braking / Coasting
      const topSpeed = spec.maxSpeed * (r.isNitroActive ? spec.nitroBoost : 1.0);
      const accelBoost = r.isNitroActive ? 1.55 : 1.0;

      if (input.accel || r.isNitroActive) {
        r.speed += spec.accelRate * accelBoost * dt;
      } else if (input.brake) {
        if (r.speed > 0) {
          r.speed -= 56 * dt;
        } else {
          r.speed -= 18 * dt;
        }
      } else {
        // Aerodynamic drag + rolling resistance
        r.speed -= r.speed * 0.42 * dt;
        if (Math.abs(r.speed) < 0.25) r.speed = 0;
      }

      r.speed = Math.max(-14, Math.min(topSpeed, r.speed));

      // Steering physics
      const steerInput = (input.right ? 1 : 0) - (input.left ? 1 : 0);
      const speedTurnFactor = Math.min(1.0, Math.abs(r.speed) / 14);
      const targetSteer = steerInput * 0.34 * speedTurnFactor;
      r.steerAngle += (targetSteer - r.steerAngle) * Math.min(1, dt * 11);

      const lateralMove = steerInput * spec.steerSpeed * speedTurnFactor * dt;
      r.playerX += lateralMove;

      // Barrier Scrape Collision
      if (Math.abs(r.playerX) > BARRIER_LIMIT) {
        r.playerX = Math.sign(r.playerX) * BARRIER_LIMIT;
        if (r.speed > 18) {
          r.speed *= 0.94;
          this.spawnBurst(r.playerX + Math.sign(r.playerX) * 0.9, 0.5, r.playerZ, 0xff5500, 3);
        }
      }

      // Advance forward along -Z
      const dz = r.speed * dt;
      r.playerZ -= dz;
      if (dz > 0) {
        r.distanceMeters += dz * 1.15;
      }

      // Car visual animations (body roll, pitch, wheels, brake lights, nitro flames, invuln blink)
      const car = this.playerCar;
      car.group.position.set(r.playerX, 0, r.playerZ);
      car.group.rotation.y = -r.steerAngle * 0.65;

      // Body roll & pitch
      const targetRoll = -r.steerAngle * 0.26;
      const targetPitch = input.brake && r.speed > 4 ? -0.045 : r.isNitroActive ? 0.04 : input.accel ? 0.022 : 0;
      car.chassis.rotation.z += (targetRoll - car.chassis.rotation.z) * Math.min(1, dt * 10);
      car.chassis.rotation.x += (targetPitch - car.chassis.rotation.x) * Math.min(1, dt * 8);

      // Front wheel steering & 4-wheel spin
      car.frontSteerPivots.forEach((p) => {
        p.rotation.y = -r.steerAngle * 1.1;
      });
      const wheelSpin = -dz / 0.38;
      car.wheels.forEach((w) => {
        w.rotation.x += wheelSpin;
      });

      // Taillight brightness on brake
      car.brakeMat.color.setHex(input.brake ? 0xff453a : 0xa80b0b);

      // Nitro exhaust flames
      car.nitroFlames.forEach((fg) => {
        fg.visible = r.isNitroActive;
        if (r.isNitroActive) {
          const flick = 0.82 + Math.random() * 0.45;
          fg.scale.set(1, 1, flick);
        }
      });

      // Invulnerability blink after traffic crash
      if (r.invulnTimer > 0) {
        car.group.visible = Math.floor(r.invulnTimer * 14) % 2 === 0;
      } else {
        car.group.visible = true;
      }

      // Move sun light shadow frustum with player
      this.sunLight.position.set(r.playerX + 22, 34, r.playerZ - 14);
      this.sunLight.target.position.set(r.playerX, 0, r.playerZ - 18);

      // Recycle highway chunks
      for (let i = 0; i < this.chunks.length; i++) {
        const c = this.chunks[i];
        if (c.position.z > r.playerZ + CHUNK_LEN * 1.2) {
          c.position.z -= CHUNK_COUNT * CHUNK_LEN;
        }
      }

      // Update Traffic & Check Collisions / Near-Misses
      for (let i = 0; i < this.trafficPool.length; i++) {
        const t = this.trafficPool[i];
        t.mesh.position.z -= t.speed * dt;

        // Recycle traffic passed behind player
        if (t.mesh.position.z > r.playerZ + 28) {
          const newZ = r.playerZ - 260 - Math.random() * 140;
          const newLane = this.pickSafeLane(newZ);
          t.laneIdx = newLane;
          t.mesh.position.set(LANE_X[newLane], 0, newZ);
          t.passedNearMiss = false;
        }

        // Collision AABB check
        const dx = Math.abs(r.playerX - t.mesh.position.x);
        const dzCar = Math.abs(r.playerZ - t.mesh.position.z);
        const hitW = 0.95 + (t.mesh.userData.halfWidth || 0.95);
        const hitL = 2.15 + (t.mesh.userData.halfLength || 2.1);

        if (dx < hitW && dzCar < hitL) {
          if (r.invulnTimer <= 0) {
            this.handleTrafficCrash(t);
          }
        } else if (
          !t.passedNearMiss &&
          r.speed > 40 &&
          dzCar < 3.6 &&
          dx >= hitW &&
          dx < hitW + 1.45
        ) {
          t.passedNearMiss = true;
          if (r.nearMissBonusCooldown <= 0) {
            r.nearMissBonusCooldown = 0.7;
            r.coinsCollected += 15;
            r.nitro = Math.min(100, r.nitro + 14);
            global.FossaAudio.playNearMiss();
            if (this.cb.onEvent) this.cb.onEvent('NEAR MISS! +15 COINS');
          }
        }
      }

      // Update & Collect Coins
      if (r.playerZ < r.nextCoinSpawnZ + 180) {
        this.spawnCoinWave(r.nextCoinSpawnZ);
        r.nextCoinSpawnZ -= 95 + Math.random() * 35;
      }

      for (let i = this.coins.length - 1; i >= 0; i--) {
        const c = this.coins[i];
        c.mesh.rotation.y += dt * 3.8;
        c.mesh.position.y = 0.95 + Math.sin(r.elapsedSec * 5 + i) * 0.14;

        const dx = r.playerX - c.mesh.position.x;
        const dzCoin = r.playerZ - c.mesh.position.z;
        const distSq = dx * dx + dzCoin * dzCoin;

        // Slight magnetic pull when very close
        if (distSq < 18) {
          c.mesh.position.x += dx * dt * 6;
          c.mesh.position.z += dzCoin * dt * 6;
        }

        if (distSq < 4.2) {
          r.coinsCollected += 5;
          r.nitro = Math.min(100, r.nitro + 4);
          this.spawnBurst(c.mesh.position.x, 1.0, c.mesh.position.z, 0xffd23f, 7);
          global.FossaAudio.playCoin();
          this.vibrate(18);
          this.worldGroup.remove(c.mesh);
          this.coins.splice(i, 1);
          continue;
        }

        if (c.mesh.position.z > r.playerZ + 22) {
          this.worldGroup.remove(c.mesh);
          this.coins.splice(i, 1);
        }
      }

      // Update burst particles
      for (let i = 0; i < this.particles.length; i++) {
        const p = this.particles[i];
        if (p.life > 0) {
          p.life -= dt;
          p.vy -= 18 * dt;
          p.mesh.position.x += p.vx * dt;
          p.mesh.position.y += p.vy * dt;
          p.mesh.position.z += p.vz * dt;
          p.mesh.material.opacity = Math.max(0, p.life * 2);
          if (p.life <= 0) {
            p.mesh.visible = false;
          }
        }
      }
    }

    handleTrafficCrash(trafficObj) {
      const r = this.race;
      r.collisions += 1;
      r.shieldsLeft = Math.max(0, r.maxShields - r.collisions);
      r.invulnTimer = 1.6;
      r.shakeTimer = 0.35;
      r.speed = Math.max(12, r.speed * 0.38);

      // Push player slightly away from traffic lane
      const pushDir = r.playerX >= trafficObj.mesh.position.x ? 1 : -1;
      r.playerX = Math.max(-BARRIER_LIMIT, Math.min(BARRIER_LIMIT, r.playerX + pushDir * 1.4));

      this.spawnBurst(r.playerX, 0.9, r.playerZ - 1.5, 0xe10600, 14);
      global.FossaAudio.playCollision();
      this.vibrate(110);
      if (this.cb.onCollision) this.cb.onCollision(r.shieldsLeft);
    }

    updateCamera(dt) {
      const r = this.race;
      const speedNorm = Math.min(1, Math.max(0, r.speed / (r.carSpec ? r.carSpec.maxSpeed : 80)));

      // Dynamic FOV on high speed / nitro
      const targetFov = 62 + speedNorm * 8 + (r.isNitroActive ? 9 : 0);
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 6);
      this.camera.updateProjectionMatrix();

      // Smooth chase camera offset behind car + subtle steering rotation
      const desiredX = r.playerX * 0.78 - r.steerAngle * 2.1;
      const desiredY = 3.45 + speedNorm * 0.25;
      const desiredZ = r.playerZ + 8.3 + speedNorm * 0.9 + (r.isNitroActive ? 0.65 : 0);

      let shakeX = 0;
      let shakeY = 0;
      if (r.shakeTimer > 0) {
        const mag = r.shakeTimer * 0.9;
        shakeX = (Math.random() - 0.5) * mag;
        shakeY = (Math.random() - 0.5) * mag;
      }

      this.camera.position.x += (desiredX - this.camera.position.x) * Math.min(1, dt * 8.5);
      this.camera.position.y += (desiredY - this.camera.position.y) * Math.min(1, dt * 8.5);
      this.camera.position.z = desiredZ;

      this.camera.position.x += shakeX;
      this.camera.position.y += shakeY;

      this.camera.lookAt(r.playerX + r.steerAngle * 3.2, 1.35, r.playerZ - 14);
    }

    vibrate(ms) {
      try {
        if (global.FossaAndroid && typeof global.FossaAndroid.vibrate === 'function') {
          global.FossaAndroid.vibrate(ms);
        }
      } catch (_) {}
    }
  }

  global.FossaEngine = FossaEngine;
})(window);
