(function (global) {
  'use strict';

  const Data = global.FossaData;
  const Audio = global.FossaAudio;
  const Ads = global.FossaAdHooks;

  const el = (id) => document.getElementById(id);

  let save = Data.loadSave();
  let engine = null;
  let currentScreen = 'MENU'; // MENU | GARAGE | MISSIONS | COUNTDOWN | RACING | PAUSED | RESULTS
  let activeMission = null; // null = Quick Race
  let selectedGarageCarId = save.equippedCarId;
  let countdownTimerId = null;
  let calloutTimeoutId = null;
  let lastFrameTime = performance.now();

  const input = {
    left: false,
    right: false,
    accel: false,
    brake: false,
    nitro: false,
  };

  function formatTime(sec) {
    const s = Math.max(0, sec);
    const mins = Math.floor(s / 60);
    const rem = s % 60;
    const whole = Math.floor(rem);
    const tenths = Math.floor((rem - whole) * 10);
    return `${String(mins).padStart(2, '0')}:${String(whole).padStart(2, '0')}.${tenths}`;
  }

  function showScreen(screenName) {
    currentScreen = screenName;
    Ads.notifyScreen(screenName);

    el('boot-screen').classList.add('hidden');
    el('menu-screen').classList.toggle('hidden', screenName !== 'MENU');
    el('garage-screen').classList.toggle('hidden', screenName !== 'GARAGE');
    el('missions-screen').classList.toggle('hidden', screenName !== 'MISSIONS');
    el('hud-screen').classList.toggle(
      'hidden',
      screenName !== 'RACING' && screenName !== 'COUNTDOWN' && screenName !== 'PAUSED'
    );
    el('pause-screen').classList.toggle('hidden', screenName !== 'PAUSED');
    el('results-screen').classList.toggle('hidden', screenName !== 'RESULTS');
    el('countdown-overlay').classList.toggle('hidden', screenName !== 'COUNTDOWN');

    if (screenName !== 'RACING') {
      el('nitro-speed-lines').classList.add('hidden');
      clearAllInputs();
    }
  }

  function clearAllInputs() {
    input.left = false;
    input.right = false;
    input.accel = false;
    input.brake = false;
    input.nitro = false;
    document.querySelectorAll('.touch-btn.pressed').forEach((b) => b.classList.remove('pressed'));
  }

  function refreshMenuUI() {
    const car = Data.getCarById(save.equippedCarId);
    el('menu-coins-value').textContent = save.coins;
    el('menu-car-name').textContent = car.name;
    el('menu-car-class').textContent = car.tier;
    el('menu-stat-speed').textContent = car.topSpeedKmh;
    el('menu-stat-nitro').textContent = car.nitroStat;

    const totalStars = Object.values(save.missionStars).reduce((a, b) => a + b, 0);
    el('menu-missions-stars').textContent = `${totalStars} / ${Data.MISSIONS.length * 3} ★`;
    el('menu-garage-count').textContent = `${save.unlockedCars.length} / ${Data.CARS.length}`;

    el('sound-icon-label').textContent = save.soundEnabled ? 'SFX: ON' : 'SFX: OFF';
    el('btn-pause-sound').textContent = save.soundEnabled ? 'SOUND: ON' : 'SOUND: OFF';
    el('quality-label').textContent = save.highQuality ? 'GFX: HIGH' : 'GFX: ECO';

    const menuRewardBtn = el('btn-menu-reward-500');
    if (menuRewardBtn) {
      menuRewardBtn.classList.toggle('hidden', !Ads.isNativeSdkLinked());
      menuRewardBtn.disabled = false;
      menuRewardBtn.textContent = '+500 COINS (WATCH AD)';
    }
  }

  function openMenu() {
    clearCountdown();
    Audio.stopEngine();
    const car = Data.getCarById(save.equippedCarId);
    const color = save.carColors[car.id] ?? car.defaultColor;
    engine.enterShowroomMode(car, color);
    refreshMenuUI();
    showScreen('MENU');
  }

  function openGarage() {
    Audio.playClick();
    selectedGarageCarId = save.equippedCarId;
    renderGarage();
    showScreen('GARAGE');
  }

  function renderGarage() {
    el('garage-coins-value').textContent = save.coins;
    const listEl = el('garage-car-list');
    listEl.innerHTML = '';

    Data.CARS.forEach((car) => {
      const owned = save.unlockedCars.includes(car.id);
      const equipped = save.equippedCarId === car.id;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'garage-car-item' + (car.id === selectedGarageCarId ? ' selected' : '');
      btn.innerHTML = `
        <div class="garage-item-name">${car.name}</div>
        <div class="garage-item-meta">
          <span>${car.tier}</span>
          <span>${equipped ? 'EQUIPPED' : owned ? 'OWNED' : car.price + ' F'}</span>
        </div>
      `;
      btn.addEventListener('click', () => {
        Audio.playClick();
        selectedGarageCarId = car.id;
        renderGarage();
      });
      listEl.appendChild(btn);
    });

    const car = Data.getCarById(selectedGarageCarId);
    const owned = save.unlockedCars.includes(car.id);
    const equipped = save.equippedCarId === car.id;
    const paintHex = save.carColors[car.id] ?? car.defaultColor;

    engine.enterShowroomMode(car, paintHex);

    el('garage-car-tier').textContent = car.tier;
    el('garage-car-name').textContent = car.name;
    const priceBadge = el('garage-car-price-badge');
    priceBadge.textContent = equipped ? 'EQUIPPED' : owned ? 'OWNED' : `${car.price} COINS`;
    priceBadge.classList.toggle('owned', owned);

    el('stat-val-speed').textContent = `${car.topSpeedKmh} km/h`;
    el('stat-bar-speed').style.width = `${Math.min(100, Math.round((car.topSpeedKmh / 380) * 100))}%`;
    el('stat-val-accel').textContent = car.accelStat;
    el('stat-bar-accel').style.width = `${car.accelStat}%`;
    el('stat-val-handling').textContent = car.handlingStat;
    el('stat-bar-handling').style.width = `${car.handlingStat}%`;
    el('stat-val-nitro').textContent = car.nitroStat;
    el('stat-bar-nitro').style.width = `${car.nitroStat}%`;

    const swatchBox = el('garage-paint-swatches');
    swatchBox.innerHTML = '';
    Data.PAINT_PALETTE.forEach((p) => {
      const sw = document.createElement('button');
      sw.type = 'button';
      sw.className = 'paint-swatch' + (p.hex === paintHex ? ' active' : '');
      sw.style.background = p.css;
      sw.setAttribute('aria-label', p.name);
      sw.addEventListener('click', () => {
        Audio.playClick();
        save.carColors[car.id] = p.hex;
        Data.persistSave(save);
        renderGarage();
      });
      swatchBox.appendChild(sw);
    });

    const actionBtn = el('btn-garage-action');
    if (equipped) {
      actionBtn.textContent = 'EQUIPPED';
      actionBtn.disabled = true;
    } else if (owned) {
      actionBtn.textContent = 'EQUIP CAR';
      actionBtn.disabled = false;
    } else {
      actionBtn.textContent = `BUY FOR ${car.price} COINS`;
      actionBtn.disabled = save.coins < car.price;
    }
  }

  function handleGarageAction() {
    const car = Data.getCarById(selectedGarageCarId);
    const owned = save.unlockedCars.includes(car.id);
    if (!owned) {
      if (save.coins < car.price) return;
      save.coins -= car.price;
      save.unlockedCars.push(car.id);
    }
    save.equippedCarId = car.id;
    Data.persistSave(save);
    Audio.playCoin();
    renderGarage();
  }

  function openMissions() {
    Audio.playClick();
    el('missions-coins-value').textContent = save.coins;
    const grid = el('missions-grid');
    grid.innerHTML = '';

    Data.MISSIONS.forEach((m, idx) => {
      const unlocked = Data.isMissionUnlocked(idx, save);
      const stars = save.missionStars[m.id] || 0;
      const starStr = '★'.repeat(stars) + '☆'.repeat(3 - stars);

      const card = document.createElement('div');
      card.className = 'mission-card' + (unlocked ? '' : ' locked');
      card.innerHTML = `
        <div>
          <div class="mission-head">
            <span class="mission-num">${m.number}</span>
            <span class="mission-stars">${starStr}</span>
          </div>
          <h3 class="mission-title">${m.title}</h3>
          <p class="mission-desc">${m.description}</p>
        </div>
        <div class="mission-footer">
          <span class="mission-reward">+${m.rewardCoins} COINS</span>
          <button type="button" class="btn-primary mission-play-btn" ${unlocked ? '' : 'disabled'}>
            ${unlocked ? 'RACE' : 'LOCKED'}
          </button>
        </div>
      `;

      const playBtn = card.querySelector('.mission-play-btn');
      if (unlocked) {
        playBtn.addEventListener('click', () => {
          Audio.playClick();
          launchRace(m);
        });
      }
      grid.appendChild(card);
    });

    showScreen('MISSIONS');
  }

  function clearCountdown() {
    if (countdownTimerId) {
      clearTimeout(countdownTimerId);
      countdownTimerId = null;
    }
  }

  function launchRace(mission) {
    clearCountdown();
    activeMission = mission || null;
    const car = Data.getCarById(save.equippedCarId);
    const color = save.carColors[car.id] ?? car.defaultColor;

    Ads.preloadPostRaceInterstitial();
    Ads.preloadRewarded();
    engine.startRace(car, color, activeMission);
    Audio.startEngine();

    el('hud-mission-title').textContent = activeMission ? activeMission.number : 'QUICK RACE';
    el('hud-mission-goal').textContent = activeMission
      ? `TARGET: ${activeMission.targetDistanceKm.toFixed(2)} km`
      : 'ENDLESS HIGHWAY';
    el('hud-coins').textContent = '0';
    el('hud-timer').textContent = activeMission ? formatTime(activeMission.timeLimitSec) : '00:00.0';
    el('hud-distance').textContent = '0.00 km';
    el('hud-speed').textContent = '0';
    el('hud-gear').textContent = '1';
    el('hud-nitro-fill').style.width = '100%';
    updateShieldDisplay(engine.race.shieldsLeft, engine.race.maxShields);

    showScreen('COUNTDOWN');

    let step = 3;
    const runStep = () => {
      if (currentScreen !== 'COUNTDOWN') return;
      const txt = el('countdown-text');
      if (step > 0) {
        txt.textContent = String(step);
        txt.style.animation = 'none';
        void txt.offsetWidth;
        txt.style.animation = '';
        Audio.playCountdown(false);
        step--;
        countdownTimerId = setTimeout(runStep, 700);
      } else {
        txt.textContent = 'GO!';
        txt.style.animation = 'none';
        void txt.offsetWidth;
        txt.style.animation = '';
        Audio.playCountdown(true);
        engine.setRacePaused(false);
        showScreen('RACING');
      }
    };
    runStep();
  }

  function updateShieldDisplay(left, max) {
    const filled = '■'.repeat(Math.max(0, left));
    const empty = '□'.repeat(Math.max(0, max - left));
    el('hud-hearts').textContent = filled + empty;
  }

  function showCallout(text) {
    const node = el('hud-callout');
    node.textContent = text;
    node.classList.remove('hidden');
    if (calloutTimeoutId) clearTimeout(calloutTimeoutId);
    calloutTimeoutId = setTimeout(() => node.classList.add('hidden'), 1100);
  }

  function triggerImpactFlash() {
    const flash = el('impact-flash');
    flash.classList.remove('hidden');
    setTimeout(() => flash.classList.add('hidden'), 180);
  }

  function pauseRace() {
    if (currentScreen !== 'RACING') return;
    engine.setRacePaused(true);
    Audio.updateEngine(0, false, true);
    showScreen('PAUSED');
  }

  function resumeRace() {
    if (currentScreen !== 'PAUSED') return;
    engine.setRacePaused(false);
    showScreen('RACING');
  }

  function finishRace(success, reasonText) {
    if (currentScreen === 'RESULTS') return;
    engine.setRacePaused(true);
    Audio.stopEngine();

    const r = engine.race;
    const distanceKm = r.distanceMeters / 1000;
    if (distanceKm > save.bestDistanceKm) {
      save.bestDistanceKm = Number(distanceKm.toFixed(2));
    }

    let stars = 0;
    let bonusCoins = 0;
    if (activeMission) {
      if (success) {
        const timeRatio = r.elapsedSec / activeMission.timeLimitSec;
        stars = r.collisions === 0 && timeRatio < 0.88 ? 3 : r.collisions <= 1 ? 2 : 1;
        const prevStars = save.missionStars[activeMission.id] || 0;
        if (stars > prevStars) save.missionStars[activeMission.id] = stars;
        bonusCoins = activeMission.rewardCoins;
      }
    } else {
      bonusCoins = Math.floor(distanceKm * 45);
      stars = distanceKm >= 2.5 ? 3 : distanceKm >= 1.2 ? 2 : 1;
    }

    const totalEarned = r.coinsCollected + bonusCoins;
    save.coins += totalEarned;
    Data.persistSave(save);

    el('results-badge').textContent = activeMission
      ? success
        ? 'MISSION ACCOMPLISHED'
        : 'MISSION FAILED'
      : 'RACE COMPLETE';
    el('results-title').textContent = success ? 'VICTORY!' : 'OUT OF ACTION';
    el('results-stars').textContent = '★'.repeat(stars) + '☆'.repeat(3 - stars);
    el('res-distance').textContent = `${distanceKm.toFixed(2)} km`;
    el('res-time').textContent = formatTime(r.elapsedSec);
    el('res-top-speed').textContent = `${r.topSpeedKmh} km/h`;
    el('res-coins').textContent = `+${totalEarned}`;
    el('results-subnote').textContent =
      reasonText || `Collected ${r.coinsCollected} track coins + ${bonusCoins} race bonus.`;

    // Rewarded Ad +500 Coins button (strictly verifies reward callback before granting coins)
    const rewardBtn = el('btn-res-double');
    if (rewardBtn) {
      const canClaim = Ads.isNativeSdkLinked();
      rewardBtn.classList.toggle('hidden', !canClaim);
      rewardBtn.disabled = false;
      rewardBtn.textContent = '+500 COINS (AD)';
      rewardBtn.onclick = () => {
        Audio.playClick();
        rewardBtn.disabled = true;
        rewardBtn.textContent = 'LOADING AD...';
        Ads.requestRewarded500Coins((res) => {
          if (res && res.shown === true && res.rewarded === true && Number(res.rewardAmount) === 500) {
            save.coins += 500;
            Data.persistSave(save);
            el('res-coins').textContent = `+${totalEarned + 500}`;
            el('results-subnote').textContent = 'Reward verified! +500 bonus coins added to your bank.';
            rewardBtn.textContent = '+500 CLAIMED ✓';
            Audio.playCoin();
          } else {
            rewardBtn.disabled = false;
            rewardBtn.textContent = '+500 COINS (AD)';
            el('results-subnote').textContent =
              (res && res.message) || 'Complete the rewarded ad to claim +500 coins.';
          }
        });
      };
    }

    // Show Next Mission button if mission succeeded and another exists
    const nextBtn = el('btn-res-next');
    if (activeMission && success) {
      const idx = Data.MISSIONS.findIndex((m) => m.id === activeMission.id);
      const hasNext = idx >= 0 && idx + 1 < Data.MISSIONS.length;
      nextBtn.classList.toggle('hidden', !hasNext);
      nextBtn.onclick = () => {
        Audio.playClick();
        launchRace(Data.MISSIONS[idx + 1]);
      };
    } else {
      nextBtn.classList.add('hidden');
    }

    Ads.requestPostRaceInterstitial(() => {
      showScreen('RESULTS');
    });
  }

  function updateHudFromTelemetry(t) {
    if (!t) return;

    el('hud-speed').textContent = String(t.speedKmh);
    const gear = t.speedKmh < 5 ? 'N' : Math.min(6, Math.max(1, Math.ceil((t.speedKmh / t.maxSpeedKmh) * 6)));
    el('hud-gear').textContent = String(gear);

    // SVG arc length = 201
    const pct = Math.min(1, t.speedKmh / Math.max(1, t.maxSpeedKmh * 1.2));
    el('speedo-active-arc').style.strokeDashoffset = String(Math.round(201 * (1 - pct)));
    el('speedo-active-arc').style.stroke = t.isNitroActive ? '#00e5ff' : '#e10600';

    el('hud-nitro-fill').style.width = `${Math.round(t.nitro)}%`;
    el('nitro-speed-lines').classList.toggle('hidden', !t.isNitroActive);

    el('hud-distance').textContent = `${t.distanceKm.toFixed(2)} km`;
    el('hud-coins').textContent = String(t.coinsCollected);

    if (activeMission) {
      const rem = Math.max(0, activeMission.timeLimitSec - t.elapsedSec);
      el('hud-timer').textContent = formatTime(rem);

      const distGoal = `${t.distanceKm.toFixed(2)}/${activeMission.targetDistanceKm.toFixed(2)} km`;
      const coinGoal =
        activeMission.targetCoins > 0 ? ` • ${t.coinsCollected}/${activeMission.targetCoins} F` : '';
      el('hud-mission-goal').textContent = distGoal + coinGoal;

      if (
        t.distanceKm >= activeMission.targetDistanceKm &&
        t.coinsCollected >= activeMission.targetCoins
      ) {
        finishRace(true, `Target reached in ${formatTime(t.elapsedSec)}!`);
      } else if (rem <= 0) {
        finishRace(false, 'Time expired before reaching the target.');
      } else if (t.shieldsLeft <= 0) {
        finishRace(false, 'Too many traffic collisions!');
      }
    } else {
      el('hud-timer').textContent = formatTime(t.elapsedSec);
      if (t.shieldsLeft <= 0) {
        finishRace(true, `Highway run ended after ${t.distanceKm.toFixed(2)} km!`);
      }
    }

    Audio.updateEngine(t.speedRatio, t.isNitroActive, currentScreen !== 'RACING');
  }

  function bindTouchHoldButton(buttonEl, inputKey) {
    const activeIds = new Set();

    const sync = () => {
      const isDown = activeIds.size > 0;
      input[inputKey] = isDown;
      buttonEl.classList.toggle('pressed', isDown);
    };

    buttonEl.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      Audio.ensureContext();
      activeIds.add(e.pointerId);
      sync();
    });

    const release = (e) => {
      if (activeIds.has(e.pointerId)) {
        activeIds.delete(e.pointerId);
        sync();
      }
    };

    window.addEventListener('pointerup', release);
    window.addEventListener('pointercancel', release);
    buttonEl.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  function bindKeyboardControls() {
    const map = {
      ArrowLeft: 'left',
      KeyA: 'left',
      ArrowRight: 'right',
      KeyD: 'right',
      ArrowUp: 'accel',
      KeyW: 'accel',
      ArrowDown: 'brake',
      KeyS: 'brake',
      Space: 'nitro',
      ShiftLeft: 'nitro',
    };
    window.addEventListener('keydown', (e) => {
      const k = map[e.code];
      if (k && currentScreen === 'RACING') {
        input[k] = true;
      }
      if (e.code === 'Escape') {
        handleAndroidBack();
      }
    });
    window.addEventListener('keyup', (e) => {
      const k = map[e.code];
      if (k) input[k] = false;
    });
  }

  function bindShowroomDrag() {
    const canvas = el('game-canvas');
    let dragging = false;
    let lastX = 0;

    canvas.addEventListener('pointerdown', (e) => {
      if (currentScreen === 'MENU' || currentScreen === 'GARAGE') {
        dragging = true;
        lastX = e.clientX;
      }
    });
    window.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      lastX = e.clientX;
      engine.rotateShowroom(dx * 0.01);
    });
    window.addEventListener('pointerup', () => {
      dragging = false;
    });
  }

  function handleAndroidBack() {
    if (currentScreen === 'RACING' || currentScreen === 'COUNTDOWN') {
      pauseRace();
    } else if (currentScreen === 'PAUSED') {
      resumeRace();
    } else if (currentScreen === 'GARAGE' || currentScreen === 'MISSIONS' || currentScreen === 'RESULTS') {
      openMenu();
    }
  }

  function gameLoop(now) {
    const dt = (now - lastFrameTime) / 1000;
    lastFrameTime = now;

    if (engine) {
      const telemetry = engine.update(dt, input);
      if (currentScreen === 'RACING' && telemetry) {
        updateHudFromTelemetry(telemetry);
      }
    }

    requestAnimationFrame(gameLoop);
  }

  function init() {
    Audio.setEnabled(save.soundEnabled);

    engine = new global.FossaEngine(el('game-canvas'), {
      onEvent: (msg) => showCallout(msg),
      onCollision: (shieldsLeft) => {
        triggerImpactFlash();
        updateShieldDisplay(shieldsLeft, engine.race.maxShields);
        showCallout('COLLISION!');
      },
    });
    engine.setQuality(save.highQuality);

    // Wire UI Buttons
    el('btn-quick-race').addEventListener('click', () => {
      Audio.playClick();
      launchRace(null);
    });
    el('btn-missions').addEventListener('click', openMissions);
    el('btn-garage').addEventListener('click', openGarage);

    const menuRewardBtn = el('btn-menu-reward-500');
    if (menuRewardBtn) {
      menuRewardBtn.addEventListener('click', () => {
        Audio.playClick();
        menuRewardBtn.disabled = true;
        menuRewardBtn.textContent = 'LOADING AD...';
        Ads.requestRewarded500Coins((res) => {
          if (res && res.shown === true && res.rewarded === true && Number(res.rewardAmount) === 500) {
            save.coins += 500;
            Data.persistSave(save);
            el('menu-coins-value').textContent = save.coins;
            menuRewardBtn.textContent = '+500 CLAIMED ✓';
            Audio.playCoin();
            setTimeout(() => {
              if (currentScreen === 'MENU') refreshMenuUI();
            }, 1800);
          } else {
            menuRewardBtn.disabled = false;
            menuRewardBtn.textContent = '+500 COINS (WATCH AD)';
          }
        });
      });
    }

    el('btn-sound-toggle').addEventListener('click', () => {
      save.soundEnabled = !save.soundEnabled;
      Audio.setEnabled(save.soundEnabled);
      Audio.playClick();
      Data.persistSave(save);
      refreshMenuUI();
    });

    el('btn-quality-toggle').addEventListener('click', () => {
      save.highQuality = !save.highQuality;
      engine.setQuality(save.highQuality);
      Audio.playClick();
      Data.persistSave(save);
      refreshMenuUI();
    });

    el('btn-garage-back').addEventListener('click', () => {
      Audio.playClick();
      openMenu();
    });
    el('btn-garage-action').addEventListener('click', handleGarageAction);

    el('btn-missions-back').addEventListener('click', () => {
      Audio.playClick();
      openMenu();
    });

    el('btn-hud-pause').addEventListener('click', pauseRace);
    el('btn-hud-restart').addEventListener('click', () => {
      Audio.playClick();
      launchRace(activeMission);
    });

    el('btn-pause-resume').addEventListener('click', () => {
      Audio.playClick();
      resumeRace();
    });
    el('btn-pause-restart').addEventListener('click', () => {
      Audio.playClick();
      launchRace(activeMission);
    });
    el('btn-pause-sound').addEventListener('click', () => {
      save.soundEnabled = !save.soundEnabled;
      Audio.setEnabled(save.soundEnabled);
      Data.persistSave(save);
      refreshMenuUI();
    });
    el('btn-pause-menu').addEventListener('click', () => {
      Audio.playClick();
      openMenu();
    });

    el('btn-res-retry').addEventListener('click', () => {
      Audio.playClick();
      launchRace(activeMission);
    });
    el('btn-res-garage').addEventListener('click', openGarage);
    el('btn-res-menu').addEventListener('click', () => {
      Audio.playClick();
      openMenu();
    });

    // Multi-touch HUD racing buttons
    bindTouchHoldButton(el('btn-steer-left'), 'left');
    bindTouchHoldButton(el('btn-steer-right'), 'right');
    bindTouchHoldButton(el('btn-accel'), 'accel');
    bindTouchHoldButton(el('btn-brake'), 'brake');
    bindTouchHoldButton(el('btn-nitro'), 'nitro');

    bindKeyboardControls();
    bindShowroomDrag();

    window.addEventListener('resize', () => engine.resize());

    global.FossaGame = {
      handleAndroidBack,
      onAppPause: () => {
        if (currentScreen === 'RACING') pauseRace();
        Audio.stopEngine();
      },
      onAppResume: () => {
        if (currentScreen === 'RACING' || currentScreen === 'PAUSED') {
          Audio.startEngine();
        }
      },
    };

    try {
      if (global.FossaAndroid && typeof global.FossaAndroid.notifyGameReady === 'function') {
        global.FossaAndroid.notifyGameReady();
      }
    } catch (_) {}

    openMenu();
    lastFrameTime = performance.now();
    requestAnimationFrame(gameLoop);
  }

  init();
})(window);
