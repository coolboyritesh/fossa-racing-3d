package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FossaRed = Color(0xFFE10600)
val FossaRedLight = Color(0xFFFF3B30)
val FossaObsidian = Color(0xFF0A0A0D)
val FossaCarbon = Color(0xFF141419)
val FossaSteel = Color(0xFF24242E)
val FossaWhite = Color(0xFFFFFFFF)
val FossaSilver = Color(0xFFB8BCC8)
