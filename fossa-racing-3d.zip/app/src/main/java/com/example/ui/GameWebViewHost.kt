package com.example.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ads.AdBannerSlot
import com.example.ads.AdMobController
import com.example.bridge.FossaGameBridge
import com.example.data.GameProgressRepository
import java.io.IOException

private const val ASSET_HOST = "appassets.androidplatform.net"
private const val ENTRY_URL = "https://$ASSET_HOST/assets/index.html"

@Composable
fun GameWebViewHost(
  activity: Activity?,
  repository: GameProgressRepository,
  adMobController: AdMobController,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val adState by adMobController.adState.collectAsStateWithLifecycle()

  var currentScreen by remember { mutableStateOf("MENU") }
  var hasLoadError by remember { mutableStateOf(false) }
  var webViewInstance by remember { mutableStateOf<WebView?>(null) }

  val bridge = remember {
    FossaGameBridge(
      context = context,
      activity = activity,
      repository = repository,
      adMobController = adMobController,
      onScreenStateChanged = { screen -> currentScreen = screen },
      onWebReady = { hasLoadError = false },
    )
  }

  BackHandler(enabled = currentScreen != "MENU") {
    webViewInstance?.evaluateJavascript(
      "window.FossaGame && window.FossaGame.handleAndroidBack();",
      null,
    )
  }

  DisposableEffect(lifecycleOwner, webViewInstance) {
    val observer = LifecycleEventObserver { _, event ->
      val wv = webViewInstance ?: return@LifecycleEventObserver
      when (event) {
        Lifecycle.Event.ON_PAUSE -> {
          wv.evaluateJavascript("window.FossaGame && window.FossaGame.onAppPause();", null)
          wv.onPause()
        }
        Lifecycle.Event.ON_RESUME -> {
          wv.onResume()
          wv.evaluateJavascript("window.FossaGame && window.FossaGame.onAppResume();", null)
        }
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
      AndroidView(
        modifier = Modifier.fillMaxSize().testTag("fossa_webgl_view"),
        factory = { ctx ->
          createConfiguredWebView(
              context = ctx,
              bridge = bridge,
              onError = { hasLoadError = true },
            )
            .also { wv ->
              webViewInstance = wv
              bridge.attachWebView(wv)
              wv.loadUrl(ENTRY_URL)
            }
        },
        onRelease = { wv ->
          wv.stopLoading()
          wv.removeJavascriptInterface("FossaAndroid")
          wv.destroy()
          webViewInstance = null
        },
      )

      if (hasLoadError) {
        WebGlFallbackOverlay(
          onRetry = {
            hasLoadError = false
            webViewInstance?.loadUrl(ENTRY_URL)
          },
          modifier = Modifier.fillMaxSize(),
        )
      }
    }

    // Native AdMob Banner Slot (collapsed until play-services-ads SDK is enabled)
    AdBannerSlot(adState = adState)
  }
}

@SuppressLint("SetJavaScriptEnabled")
private fun createConfiguredWebView(
  context: Context,
  bridge: FossaGameBridge,
  onError: () -> Unit,
): WebView {
  return WebView(context).apply {
    layoutParams =
      ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT,
      )
    setBackgroundColor(AndroidColor.parseColor("#0A0A0D"))
    setLayerType(View.LAYER_TYPE_HARDWARE, null)
    isHorizontalScrollBarEnabled = false
    isVerticalScrollBarEnabled = false
    overScrollMode = View.OVER_SCROLL_NEVER
    isLongClickable = false
    setOnLongClickListener { true }

    settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = true
      databaseEnabled = true
      useWideViewPort = true
      loadWithOverviewMode = true
      setSupportZoom(false)
      builtInZoomControls = false
      displayZoomControls = false
      mediaPlaybackRequiresUserGesture = false
      cacheMode = WebSettings.LOAD_DEFAULT
      allowFileAccess = false
      allowContentAccess = false
    }

    addJavascriptInterface(bridge, "FossaAndroid")

    webChromeClient =
      object : WebChromeClient() {
        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
          return true
        }
      }

    webViewClient =
      object : WebViewClient() {
        override fun shouldInterceptRequest(
          view: WebView?,
          request: WebResourceRequest?,
        ): WebResourceResponse? {
          val url = request?.url ?: return null
          return interceptLocalAsset(context, url)
        }

        override fun onReceivedError(
          view: WebView?,
          request: WebResourceRequest?,
          error: WebResourceError?,
        ) {
          if (request?.isForMainFrame == true) {
            onError()
          }
        }
      }
  }
}

private fun interceptLocalAsset(context: Context, uri: Uri): WebResourceResponse? {
  if (uri.host != ASSET_HOST) return null
  val path = uri.path ?: return null
  if (!path.startsWith("/assets/")) return null
  val assetPath = path.removePrefix("/assets/").trimStart('/')
  if (assetPath.isEmpty() || assetPath.contains("..")) return null

  return try {
    val stream = context.assets.open(assetPath)
    val mimeType =
      when {
        assetPath.endsWith(".html") -> "text/html"
        assetPath.endsWith(".css") -> "text/css"
        assetPath.endsWith(".js") -> "application/javascript"
        assetPath.endsWith(".json") -> "application/json"
        assetPath.endsWith(".svg") -> "image/svg+xml"
        assetPath.endsWith(".png") -> "image/png"
        assetPath.endsWith(".jpg") || assetPath.endsWith(".jpeg") -> "image/jpeg"
        else -> "application/octet-stream"
      }
    WebResourceResponse(mimeType, "UTF-8", stream)
  } catch (_: IOException) {
    null
  }
}

@Composable
private fun WebGlFallbackOverlay(onRetry: () -> Unit, modifier: Modifier = Modifier) {
  Column(
    modifier =
      modifier
        .background(MaterialTheme.colorScheme.background)
        .safeDrawingPadding()
        .padding(24.dp),
    verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Text(
      text = stringResource(R.string.webgl_error_title),
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.primary,
      textAlign = TextAlign.Center,
    )
    Spacer(modifier = Modifier.height(12.dp))
    Text(
      text = stringResource(R.string.webgl_error_message),
      style = MaterialTheme.typography.bodyLarge,
      color = MaterialTheme.colorScheme.onBackground,
      textAlign = TextAlign.Center,
    )
    Spacer(modifier = Modifier.height(24.dp))
    Button(
      onClick = onRetry,
      colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
      modifier = Modifier.defaultMinSize(minWidth = 48.dp, minHeight = 48.dp).testTag("retry_webgl_button"),
    ) {
      Text(text = stringResource(R.string.retry_button))
    }
  }
}
