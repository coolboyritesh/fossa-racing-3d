package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val FossaDarkColorScheme =
  darkColorScheme(
    primary = FossaRed,
    onPrimary = FossaWhite,
    primaryContainer = FossaCarbon,
    onPrimaryContainer = FossaWhite,
    secondary = FossaRedLight,
    onSecondary = FossaWhite,
    background = FossaObsidian,
    onBackground = FossaWhite,
    surface = FossaCarbon,
    onSurface = FossaWhite,
    surfaceVariant = FossaSteel,
    onSurfaceVariant = FossaSilver,
    outline = FossaSteel,
  )

@Composable
fun MyApplicationTheme(content: @Composable () -> Unit) {
  MaterialTheme(colorScheme = FossaDarkColorScheme, typography = Typography, content = content)
}
