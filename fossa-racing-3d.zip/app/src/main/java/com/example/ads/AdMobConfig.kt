package com.example.ads

import com.example.BuildConfig

/**
 * Ad formats supported by the native Android Google AdMob integration layer.
 */
enum class AdFormat {
  BANNER,
  INTERSTITIAL,
  REWARDED,
}

/**
 * Logical ad placements across Fossa Racing 3D.
 * Active racing screens never display banner or interstitial ads.
 */
enum class AdPlacement(val key: String, val format: AdFormat) {
  HOME_BANNER("home_banner", AdFormat.BANNER),
  POST_RACE_INTERSTITIAL("post_race_interstitial", AdFormat.INTERSTITIAL),
  BONUS_500_COINS_REWARDED("bonus_500_coins_rewarded", AdFormat.REWARDED),
}

/**
 * Build-aware Google Mobile Ads SDK configuration.
 * - `debug` builds automatically resolve Google official test IDs via BuildConfig.
 * - `release` builds automatically resolve production AdMob IDs via BuildConfig.
 */
object AdMobConfig {
  const val IS_SDK_INTEGRATED = true
  const val REWARD_COINS_AMOUNT = 500
  const val INTERSTITIAL_COOLDOWN_MS = 90_000L

  // Reference constants for verification & separation
  const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
  const val TEST_BANNER_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
  const val TEST_INTERSTITIAL_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
  const val TEST_REWARDED_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

  const val PROD_APP_ID = "ca-app-pub-7511229662294549~7706649838"
  const val PROD_BANNER_UNIT_ID = "ca-app-pub-7511229662294549/3791455558"
  const val PROD_INTERSTITIAL_UNIT_ID = "ca-app-pub-7511229662294549/8574163894"
  const val PROD_REWARDED_UNIT_ID = "ca-app-pub-7511229662294549/4443347191"

  val isTestMode: Boolean
    get() = BuildConfig.ADMOB_TEST_MODE

  val appId: String
    get() = BuildConfig.ADMOB_APP_ID

  val bannerUnitId: String
    get() = BuildConfig.ADMOB_BANNER_UNIT_ID

  val interstitialUnitId: String
    get() = BuildConfig.ADMOB_INTERSTITIAL_UNIT_ID

  val rewardedUnitId: String
    get() = BuildConfig.ADMOB_REWARDED_UNIT_ID

  fun unitIdFor(placement: AdPlacement): String =
    when (placement.format) {
      AdFormat.BANNER -> bannerUnitId
      AdFormat.INTERSTITIAL -> interstitialUnitId
      AdFormat.REWARDED -> rewardedUnitId
    }
}

/**
 * Observable state of the native AdMob layer.
 */
data class AdUiState(
  val isSdkInitialized: Boolean = false,
  val isSdkLinked: Boolean = AdMobConfig.IS_SDK_INTEGRATED,
  val isTestMode: Boolean = AdMobConfig.isTestMode,
  val activeBannerPlacement: AdPlacement? = null,
  val isBannerVisible: Boolean = false,
  val isBannerLoaded: Boolean = false,
  val isInterstitialLoaded: Boolean = false,
  val isRewardedLoaded: Boolean = false,
  val isGameplayActive: Boolean = false,
)
