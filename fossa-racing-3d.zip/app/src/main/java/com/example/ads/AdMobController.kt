package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Result callback for full-screen native AdMob presentations.
 */
data class AdShowResult(
  val placement: AdPlacement,
  val shown: Boolean,
  val rewarded: Boolean,
  val rewardAmount: Int,
  val message: String,
)

/**
 * Clean native Android abstraction for Google AdMob (Banner, Interstitial, Rewarded).
 */
interface AdMobController {
  val adState: StateFlow<AdUiState>

  fun initialize(context: Context)

  fun setGameplayActive(active: Boolean)

  fun setBannerVisibility(visible: Boolean, placement: AdPlacement)

  fun preloadInterstitial(placement: AdPlacement)

  fun showInterstitial(
    activity: Activity?,
    placement: AdPlacement,
    onCompleted: (AdShowResult) -> Unit,
  )

  fun preloadRewarded(placement: AdPlacement)

  fun showRewarded(
    activity: Activity?,
    placement: AdPlacement,
    onCompleted: (AdShowResult) -> Unit,
  )
}

/**
 * Lightweight no-op implementation used in JVM/Robolectric unit tests.
 */
class NoOpAdMobController : AdMobController {
  private val _adState = MutableStateFlow(AdUiState(isSdkLinked = false))
  override val adState: StateFlow<AdUiState> = _adState.asStateFlow()

  override fun initialize(context: Context) {
    _adState.update { it.copy(isSdkInitialized = true, isSdkLinked = false) }
  }

  override fun setGameplayActive(active: Boolean) {
    _adState.update {
      it.copy(
        isGameplayActive = active,
        isBannerVisible = if (active) false else it.isBannerVisible,
      )
    }
  }

  override fun setBannerVisibility(visible: Boolean, placement: AdPlacement) {
    _adState.update {
      it.copy(
        activeBannerPlacement = if (visible) placement else null,
        isBannerVisible = false,
      )
    }
  }

  override fun preloadInterstitial(placement: AdPlacement) {
    Log.d(TAG, "NoOp preload interstitial: ${placement.key}")
  }

  override fun showInterstitial(
    activity: Activity?,
    placement: AdPlacement,
    onCompleted: (AdShowResult) -> Unit,
  ) {
    onCompleted(
      AdShowResult(
        placement = placement,
        shown = false,
        rewarded = false,
        rewardAmount = 0,
        message = "NoOp controller",
      )
    )
  }

  override fun preloadRewarded(placement: AdPlacement) {
    Log.d(TAG, "NoOp preload rewarded: ${placement.key}")
  }

  override fun showRewarded(
    activity: Activity?,
    placement: AdPlacement,
    onCompleted: (AdShowResult) -> Unit,
  ) {
    onCompleted(
      AdShowResult(
        placement = placement,
        shown = false,
        rewarded = false,
        rewardAmount = 0,
        message = "NoOp controller",
      )
    )
  }

  companion object {
    private const val TAG = "FossaAdMobNoOp"
  }
}

/**
 * Native Compose host slot for the Google AdMob Banner [AdView].
 * Visible on the Home Screen only when banner loads cleanly; collapsed during active racing
 * or if the banner fails to load so it never reserves empty dead space.
 */
@Composable
fun AdBannerSlot(adState: AdUiState, modifier: Modifier = Modifier) {
  if (adState.isSdkLinked && adState.isBannerVisible && !adState.isGameplayActive) {
    val placement = adState.activeBannerPlacement ?: AdPlacement.HOME_BANNER
    var hasLoaded by remember(placement) { mutableStateOf(false) }

    Box(
      modifier =
        modifier
          .fillMaxWidth()
          .height(if (hasLoaded) 50.dp else 1.dp)
          .background(MaterialTheme.colorScheme.background)
          .testTag("admob_banner_slot"),
      contentAlignment = Alignment.Center,
    ) {
      AndroidView(
        factory = { ctx ->
          AdView(ctx).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = AdMobConfig.unitIdFor(placement)
            adListener =
              object : AdListener() {
                override fun onAdLoaded() {
                  hasLoaded = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                  hasLoaded = false
                  Log.w("FossaBannerAd", "Banner failed to load (${error.code}): ${error.message}")
                }
              }
            loadAd(AdRequest.Builder().build())
          }
        },
        onRelease = { adView -> adView.destroy() },
      )
    }
  }
}
