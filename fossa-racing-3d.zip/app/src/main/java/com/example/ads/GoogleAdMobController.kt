package com.example.ads

import android.app.Activity
import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Production-ready Google Mobile Ads SDK implementation of [AdMobController].
 * - Automatically uses Google test ad unit IDs in debug builds and production IDs in release builds.
 * - Blocks interstitial presentation during active gameplay and enforces a frequency cooldown.
 * - Strictly verifies [OnUserEarnedRewardListener] callbacks before granting the 500-coin reward.
 */
class GoogleAdMobController : AdMobController {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val _adState = MutableStateFlow(AdUiState(isSdkLinked = true))
  override val adState: StateFlow<AdUiState> = _adState.asStateFlow()

  private var appContext: Context? = null
  private var isGameplayActive = false

  private var interstitialAd: InterstitialAd? = null
  private var isInterstitialLoading = false
  private var lastInterstitialShownAtMs = 0L
  private var lastInterstitialLoadFailedAtMs = 0L

  private var rewardedAd: RewardedAd? = null
  private var isRewardedLoading = false
  private var lastRewardedLoadFailedAtMs = 0L

  override fun initialize(context: Context) {
    val ctx = context.applicationContext
    appContext = ctx
    scope.launch {
      try {
        MobileAds.initialize(ctx) {
          Log.d(
            TAG,
            "Google Mobile Ads SDK initialized (testMode=${AdMobConfig.isTestMode}, appId=${AdMobConfig.appId}).",
          )
          _adState.update { it.copy(isSdkInitialized = true, isSdkLinked = true) }
          scope.launch(Dispatchers.Main) {
            preloadInterstitial(AdPlacement.POST_RACE_INTERSTITIAL)
            preloadRewarded(AdPlacement.BONUS_500_COINS_REWARDED)
          }
        }
      } catch (t: Throwable) {
        Log.w(TAG, "MobileAds initialization unavailable: ${t.message}")
        _adState.update { it.copy(isSdkInitialized = false, isSdkLinked = true) }
      }
    }
  }

  override fun setGameplayActive(active: Boolean) {
    isGameplayActive = active
    _adState.update {
      it.copy(
        isGameplayActive = active,
        isBannerVisible = if (active) false else it.isBannerVisible,
      )
    }
  }

  override fun setBannerVisibility(visible: Boolean, placement: AdPlacement) {
    val safeVisible = visible && !isGameplayActive
    _adState.update {
      it.copy(
        activeBannerPlacement = if (safeVisible) placement else null,
        isBannerVisible = safeVisible,
      )
    }
  }

  override fun preloadInterstitial(placement: AdPlacement) {
    val ctx = appContext ?: return
    if (interstitialAd != null || isInterstitialLoading) return
    val now = SystemClock.elapsedRealtime()
    if (now - lastInterstitialLoadFailedAtMs < RETRY_BACKOFF_MS) return

    isInterstitialLoading = true
    val request = AdRequest.Builder().build()
    InterstitialAd.load(
      ctx,
      AdMobConfig.unitIdFor(placement),
      request,
      object : InterstitialAdLoadCallback() {
        override fun onAdLoaded(ad: InterstitialAd) {
          isInterstitialLoading = false
          interstitialAd = ad
          _adState.update { it.copy(isInterstitialLoaded = true) }
          Log.d(TAG, "Interstitial loaded (${placement.key}).")
        }

        override fun onAdFailedToLoad(error: LoadAdError) {
          isInterstitialLoading = false
          interstitialAd = null
          lastInterstitialLoadFailedAtMs = SystemClock.elapsedRealtime()
          _adState.update { it.copy(isInterstitialLoaded = false) }
          Log.w(TAG, "Interstitial failed to load (${error.code}): ${error.message}")
        }
      },
    )
  }

  override fun showInterstitial(
    activity: Activity?,
    placement: AdPlacement,
    onCompleted: (AdShowResult) -> Unit,
  ) {
    // Requirement 8: Never show interstitial ads during active gameplay
    if (isGameplayActive) {
      Log.w(TAG, "Blocked interstitial attempt during active gameplay.")
      onCompleted(
        AdShowResult(
          placement = placement,
          shown = false,
          rewarded = false,
          rewardAmount = 0,
          message = "Blocked during active gameplay",
        )
      )
      return
    }

    // Requirement 9: Prevent excessive ad frequency
    val now = SystemClock.elapsedRealtime()
    if (lastInterstitialShownAtMs > 0L && now - lastInterstitialShownAtMs < AdMobConfig.INTERSTITIAL_COOLDOWN_MS) {
      Log.d(TAG, "Skipping interstitial due to frequency cooldown.")
      onCompleted(
        AdShowResult(
          placement = placement,
          shown = false,
          rewarded = false,
          rewardAmount = 0,
          message = "Interstitial cooldown active",
        )
      )
      return
    }

    val ad = interstitialAd
    if (activity == null || activity.isFinishing || activity.isDestroyed || ad == null) {
      preloadInterstitial(placement)
      onCompleted(
        AdShowResult(
          placement = placement,
          shown = false,
          rewarded = false,
          rewardAmount = 0,
          message = "Interstitial not ready",
        )
      )
      return
    }

    ad.fullScreenContentCallback =
      object : FullScreenContentCallback() {
        override fun onAdShowedFullScreenContent() {
          lastInterstitialShownAtMs = SystemClock.elapsedRealtime()
        }

        override fun onAdDismissedFullScreenContent() {
          interstitialAd = null
          _adState.update { it.copy(isInterstitialLoaded = false) }
          preloadInterstitial(placement)
          onCompleted(
            AdShowResult(
              placement = placement,
              shown = true,
              rewarded = false,
              rewardAmount = 0,
              message = "Interstitial dismissed",
            )
          )
        }

        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
          interstitialAd = null
          _adState.update { it.copy(isInterstitialLoaded = false) }
          preloadInterstitial(placement)
          Log.w(TAG, "Interstitial failed to show (${adError.code}): ${adError.message}")
          onCompleted(
            AdShowResult(
              placement = placement,
              shown = false,
              rewarded = false,
              rewardAmount = 0,
              message = adError.message,
            )
          )
        }
      }

    ad.show(activity)
  }

  override fun preloadRewarded(placement: AdPlacement) {
    val ctx = appContext ?: return
    if (rewardedAd != null || isRewardedLoading) return
    val now = SystemClock.elapsedRealtime()
    if (now - lastRewardedLoadFailedAtMs < RETRY_BACKOFF_MS) return

    isRewardedLoading = true
    val request = AdRequest.Builder().build()
    RewardedAd.load(
      ctx,
      AdMobConfig.unitIdFor(placement),
      request,
      object : RewardedAdLoadCallback() {
        override fun onAdLoaded(ad: RewardedAd) {
          isRewardedLoading = false
          rewardedAd = ad
          _adState.update { it.copy(isRewardedLoaded = true) }
          Log.d(TAG, "Rewarded ad loaded (${placement.key}).")
        }

        override fun onAdFailedToLoad(error: LoadAdError) {
          isRewardedLoading = false
          rewardedAd = null
          lastRewardedLoadFailedAtMs = SystemClock.elapsedRealtime()
          _adState.update { it.copy(isRewardedLoaded = false) }
          Log.w(TAG, "Rewarded failed to load (${error.code}): ${error.message}")
        }
      },
    )
  }

  override fun showRewarded(
    activity: Activity?,
    placement: AdPlacement,
    onCompleted: (AdShowResult) -> Unit,
  ) {
    if (isGameplayActive) {
      onCompleted(
        AdShowResult(
          placement = placement,
          shown = false,
          rewarded = false,
          rewardAmount = 0,
          message = "Finish race before watching rewarded ad",
        )
      )
      return
    }

    val ad = rewardedAd
    if (activity == null || activity.isFinishing || activity.isDestroyed || ad == null) {
      preloadRewarded(placement)
      onCompleted(
        AdShowResult(
          placement = placement,
          shown = false,
          rewarded = false,
          rewardAmount = 0,
          message = "Rewarded ad is loading, please try again shortly",
        )
      )
      return
    }

    // Strictly verified via OnUserEarnedRewardListener callback before granting 500 coins
    var rewardVerified = false
    var verifiedAmount = 0

    ad.fullScreenContentCallback =
      object : FullScreenContentCallback() {
        override fun onAdDismissedFullScreenContent() {
          rewardedAd = null
          _adState.update { it.copy(isRewardedLoaded = false) }
          preloadRewarded(placement)
          onCompleted(
            AdShowResult(
              placement = placement,
              shown = true,
              rewarded = rewardVerified,
              rewardAmount = if (rewardVerified) verifiedAmount else 0,
              message = if (rewardVerified) "Verified +$verifiedAmount coins" else "Closed before reward earned",
            )
          )
        }

        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
          rewardedAd = null
          _adState.update { it.copy(isRewardedLoaded = false) }
          preloadRewarded(placement)
          Log.w(TAG, "Rewarded failed to show (${adError.code}): ${adError.message}")
          onCompleted(
            AdShowResult(
              placement = placement,
              shown = false,
              rewarded = false,
              rewardAmount = 0,
              message = adError.message,
            )
          )
        }
      }

    ad.show(activity) { _ ->
      rewardVerified = true
      verifiedAmount = AdMobConfig.REWARD_COINS_AMOUNT
    }
  }

  companion object {
    private const val TAG = "FossaGoogleAdMob"
    private const val RETRY_BACKOFF_MS = 15_000L
  }
}
