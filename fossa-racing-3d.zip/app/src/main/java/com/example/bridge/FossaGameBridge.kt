package com.example.bridge

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.example.ads.AdFormat
import com.example.ads.AdMobConfig
import com.example.ads.AdMobController
import com.example.ads.AdPlacement
import com.example.data.GameProgressRepository
import java.lang.ref.WeakReference
import org.json.JSONObject

/**
 * JavascriptInterface exposed to the Three.js WebGL game as `window.FossaAndroid`.
 * Handles native save storage, tactile haptic feedback, gameplay state sync, and AdMob hooks.
 */
class FossaGameBridge(
  context: Context,
  activity: Activity?,
  private val repository: GameProgressRepository,
  private val adMobController: AdMobController,
  private val onScreenStateChanged: (String) -> Unit,
  private val onWebReady: () -> Unit,
) {
  private val appContext = context.applicationContext
  private val activityRef = WeakReference(activity)
  private val mainHandler = Handler(Looper.getMainLooper())
  private var webViewRef: WeakReference<WebView>? = null

  fun attachWebView(webView: WebView) {
    webViewRef = WeakReference(webView)
  }

  @JavascriptInterface
  fun saveProgress(json: String) {
    repository.saveProgressJson(json)
  }

  @JavascriptInterface
  fun loadProgress(): String {
    return repository.loadProgressJson()
  }

  @JavascriptInterface
  fun notifyGameReady() {
    mainHandler.post { onWebReady() }
  }

  @JavascriptInterface
  fun notifyScreenChanged(screen: String) {
    mainHandler.post {
      onScreenStateChanged(screen)
      val isGameplay = screen == "RACING" || screen == "COUNTDOWN" || screen == "PAUSED"
      adMobController.setGameplayActive(isGameplay)
      // Banner Ads displayed on the Home Screen (MENU) only
      adMobController.setBannerVisibility(screen == "MENU", AdPlacement.HOME_BANNER)
    }
  }

  @JavascriptInterface
  fun vibrate(durationMs: Long) {
    val safeDuration = durationMs.coerceIn(10L, 250L)
    mainHandler.post { triggerHaptic(safeDuration) }
  }

  @JavascriptInterface
  fun isNativeAdSdkLinked(): Boolean {
    return AdMobConfig.IS_SDK_INTEGRATED
  }

  @JavascriptInterface
  fun isTestAdBuild(): Boolean {
    return AdMobConfig.isTestMode
  }

  @JavascriptInterface
  fun preloadAd(formatKey: String, placementKey: String) {
    val placement = resolvePlacement(placementKey, formatKey)
    mainHandler.post {
      when (placement.format) {
        AdFormat.INTERSTITIAL -> adMobController.preloadInterstitial(placement)
        AdFormat.REWARDED -> adMobController.preloadRewarded(placement)
        AdFormat.BANNER -> adMobController.setBannerVisibility(true, placement)
      }
    }
  }

  @JavascriptInterface
  fun showInterstitial(placementKey: String) {
    val placement = resolvePlacement(placementKey, "INTERSTITIAL")
    mainHandler.post {
      adMobController.showInterstitial(activityRef.get(), placement) { result ->
        dispatchAdCallback(
          format = "interstitial",
          placementKey = placement.key,
          shown = result.shown,
          rewarded = result.rewarded,
          rewardAmount = result.rewardAmount,
          message = result.message,
        )
      }
    }
  }

  @JavascriptInterface
  fun showRewarded(placementKey: String) {
    val placement = resolvePlacement(placementKey, "REWARDED")
    mainHandler.post {
      adMobController.showRewarded(activityRef.get(), placement) { result ->
        dispatchAdCallback(
          format = "rewarded",
          placementKey = placement.key,
          shown = result.shown,
          rewarded = result.rewarded,
          rewardAmount = result.rewardAmount,
          message = result.message,
        )
      }
    }
  }

  private fun dispatchAdCallback(
    format: String,
    placementKey: String,
    shown: Boolean,
    rewarded: Boolean,
    rewardAmount: Int,
    message: String,
  ) {
    val webView = webViewRef?.get() ?: return
    val safeFormat = JSONObject.quote(format)
    val safePlacement = JSONObject.quote(placementKey)
    val safeMsg = JSONObject.quote(message)
    val script =
      "window.onNativeAdResult && window.onNativeAdResult($safeFormat,$safePlacement,$shown,$rewarded,$rewardAmount,$safeMsg);"
    webView.evaluateJavascript(script, null)
  }

  private fun resolvePlacement(placementKey: String, formatKey: String): AdPlacement {
    return AdPlacement.entries.firstOrNull { it.key == placementKey }
      ?: when (formatKey.uppercase()) {
        "REWARDED" -> AdPlacement.BONUS_500_COINS_REWARDED
        "BANNER" -> AdPlacement.HOME_BANNER
        else -> AdPlacement.POST_RACE_INTERSTITIAL
      }
  }

  @Suppress("DEPRECATION")
  private fun triggerHaptic(durationMs: Long) {
    try {
      val vibrator =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
          val manager =
            appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
          manager?.defaultVibrator
        } else {
          appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
      if (vibrator == null || !vibrator.hasVibrator()) return
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(
          VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
        )
      } else {
        vibrator.vibrate(durationMs)
      }
    } catch (_: SecurityException) {
      // Ignore if device restricts vibration
    }
  }
}
