package com.example.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Durable local persistence repository for player coins, unlocked garage vehicles,
 * mission star progress, best records, and audio/quality preferences.
 */
class GameProgressRepository(context: Context) {
  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  fun saveProgressJson(json: String) {
    prefs.edit().putString(KEY_SAVE_JSON, json).apply()
  }

  fun loadProgressJson(): String {
    return prefs.getString(KEY_SAVE_JSON, "") ?: ""
  }

  fun clearProgress() {
    prefs.edit().remove(KEY_SAVE_JSON).apply()
  }

  companion object {
    private const val PREFS_NAME = "fossa_racing_prefs"
    private const val KEY_SAVE_JSON = "player_progress_v1"
  }
}
