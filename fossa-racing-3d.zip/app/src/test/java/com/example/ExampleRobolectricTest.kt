package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ads.AdMobConfig
import com.example.ads.AdPlacement
import com.example.ads.NoOpAdMobController
import com.example.data.GameProgressRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name matches Fossa Racing 3D`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Fossa Racing 3D", appName)
  }

  @Test
  fun `game progress repository persists save json`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = GameProgressRepository(context)
    val payload = """{"coins":640,"equippedCarId":"vipera_apex"}"""
    repo.saveProgressJson(payload)
    assertEquals(payload, repo.loadProgressJson())
  }

  @Test
  fun `debug build uses google test admob ids and never production ids`() {
    assertTrue(AdMobConfig.IS_SDK_INTEGRATED)
    assertTrue(AdMobConfig.isTestMode)
    assertEquals(AdMobConfig.TEST_APP_ID, AdMobConfig.appId)
    assertEquals(AdMobConfig.TEST_BANNER_UNIT_ID, AdMobConfig.unitIdFor(AdPlacement.HOME_BANNER))
    assertEquals(
      AdMobConfig.TEST_INTERSTITIAL_UNIT_ID,
      AdMobConfig.unitIdFor(AdPlacement.POST_RACE_INTERSTITIAL),
    )
    assertEquals(
      AdMobConfig.TEST_REWARDED_UNIT_ID,
      AdMobConfig.unitIdFor(AdPlacement.BONUS_500_COINS_REWARDED),
    )
  }

  @Test
  fun `production admob ids and 500 coin reward are configured accurately`() {
    assertEquals("ca-app-pub-7511229662294549~7706649838", AdMobConfig.PROD_APP_ID)
    assertEquals("ca-app-pub-7511229662294549/3791455558", AdMobConfig.PROD_BANNER_UNIT_ID)
    assertEquals("ca-app-pub-7511229662294549/8574163894", AdMobConfig.PROD_INTERSTITIAL_UNIT_ID)
    assertEquals("ca-app-pub-7511229662294549/4443347191", AdMobConfig.PROD_REWARDED_UNIT_ID)
    assertEquals(500, AdMobConfig.REWARD_COINS_AMOUNT)
  }

  @Test
  fun `noop controller blocks unverified rewards in unit tests`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val controller = NoOpAdMobController()
    controller.initialize(context)
    assertTrue(controller.adState.value.isSdkInitialized)

    var callbackInvoked = false
    controller.showRewarded(null, AdPlacement.BONUS_500_COINS_REWARDED) { result ->
      callbackInvoked = true
      assertFalse(result.shown)
      assertFalse(result.rewarded)
      assertEquals(0, result.rewardAmount)
    }
    assertTrue(callbackInvoked)
  }
}
